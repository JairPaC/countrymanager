import { StyleSheet, Text, TextInput, View } from "react-native";
import { GlobalColors } from "../../style/colors"

const Entry = ({ label, style, invalid, textInputConfig }) => {
  return (
    <View style={[inputStyle.container, style]}>
      <Text style={[inputStyle.label, invalid && inputStyle.invalidLabel]}>
        {label}
      </Text>
      <TextInput
        style={[inputStyle.input, invalid && inputStyle.invalidInput]}
        {...textInputConfig}
      />
    </View>
  );
};

const inputStyle = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  label: {
    fontSize: 18,
    fontFamily: "open-sans-bold",
    color: GlobalColors.primary,
    marginBottom: 4,
  },
  input: {
    backgroundColor: "white",
    padding: 16,
    borderRadius: 6,
    fontSize: 18,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: "gray",
    color: "black",
  },
  invalidLabel: {
    color: GlobalColors.red,
  },
  invalidInput: {
    borderColor: GlobalColors.red,
  },
});

export default Entry;
