import { Pressable, StyleSheet, Text, View } from "react-native";
import { GlobalColors } from "../../style/colors";

const Button = ({ children, onPress, buttonType, mode, style }) => {
  return (
    <View style={style}>
      <Pressable
        onPress={onPress}
        style={({ pressed }) => pressed && buttonStyle.pressed}
      >
        <View
          style={[
            buttonStyle.containerBase,
            mode === "flat" && buttonStyle.flat,
          ]}
        >
          <Text
            style={[
              buttonStyle.buttonText,
              mode === "flat" && buttonStyle.flatText,
            ]}
          >
            {children}
          </Text>
        </View>
      </Pressable>
    </View>
  );
};

const buttonStyle = StyleSheet.create({
  containerBase: {
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 16,
    shadowColor: "black",
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    backgroundColor: GlobalColors.primary,
  },
  primaryButton: {
    backgroundColor: GlobalColors.primary,
  },
  flat: {
    backgroundColor: "transparent",
  },
  buttonText: {
    color: "white",
    textAlign: "center",
    fontFamily: "open-sans",
    fontSize: 16,
  },
  flatText: {
    color: GlobalColors.primary,
  },
  pressed: {
    opacity: 0.75,
    backgroundColor: GlobalColors.separatorColor,
    borderRadius: 4,
  },
});

export default Button;
