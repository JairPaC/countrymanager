import { Pressable, View, StyleSheet } from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";

const IconButton = ({ icon, size, color, onPress }) => {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => pressed && iconButtonStyle.pressStyle}
    >
      <View style={iconButtonStyle.buttonContainer}>
        <Ionicons name={icon} size={size} color={color} />
      </View>
    </Pressable>
  );
};

const iconButtonStyle = StyleSheet.create({
  buttonContainer: {
    borderRadius: 24,
  },
  pressStyle: {
    opacity: 0.75,
  },
});

export default IconButton;
