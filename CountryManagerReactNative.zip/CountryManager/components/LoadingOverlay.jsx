import { ActivityIndicator, Modal, StyleSheet, Text, View } from "react-native";

const LoadingOverlay = ({
    visible = false,
    message = "Cargando...",
    color = "#000",
    size = "large",
  }) => {
    return (
        <Modal
          transparent={true}
          animationType="none"
          visible={visible}
          onRequestClose={() => {}}
        >
          <View style={loadingStyles.overlay}>
            <View style={loadingStyles.loader}>
              <ActivityIndicator size={size} color={color} />
              <Text style={loadingStyles.text}>{message}</Text>
            </View>
          </View>
        </Modal>
      );
};

const loadingStyles = StyleSheet.create({
    overlay: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "rgba(0, 0, 0, 0.5)",
    },
    loader: {
      padding: 20,
      backgroundColor: "white",
      borderRadius: 10,
      elevation: 10,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.3,
      shadowRadius: 10,
    },
    text: {
      marginTop: 10
    },
  });

export default LoadingOverlay;