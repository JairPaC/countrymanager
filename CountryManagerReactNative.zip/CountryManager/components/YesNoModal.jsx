import { Modal, StyleSheet, Text, View } from "react-native";
import Button from "./UI/Button";

const YesNoModal = ({
  title,
  message,
  acceptTitle,
  cancelTitle,
  visible,
  onSubmit,
}) => {
  function onSubmitHandler(type) {
    onSubmit(type);
  }

  return (
    <Modal
      transparent={true}
      animationType="none"
      visible={visible}
      onRequestClose={() => {}}
    >
      <View style={yestnoStyle.overlay}>
        <View style={yestnoStyle.container}>
          <Text style={yestnoStyle.title}>{title}</Text>
          <Text style={yestnoStyle.message}>{message}</Text>
          <View style={yestnoStyle.buttonContainer}>
            <View style={yestnoStyle.button}>
              <Button mode="flat" onPress={() => onSubmitHandler(0)}>
                {cancelTitle}
              </Button>
            </View>
            <View style={yestnoStyle.button}>
              <Button onPress={() => onSubmitHandler(1)}>{acceptTitle}</Button>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const yestnoStyle = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  container: {
    width: "100%",
    maxWidth: 300,
    padding: 20,
    backgroundColor: "white",
    borderRadius: 10,
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  title: {
    fontSize: 20,
    fontFamily: "open-sans-bold",
  },
  message: {
    fontSize: 18,
    fontFamily: "open-sans",
    marginVertical: 10,
  },
  buttonContainer: {
    flexDirection: "row",
  },
  button: {
    flex: 1,
    marginHorizontal: 5,
  },
});

export default YesNoModal;
