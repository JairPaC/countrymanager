import { StyleSheet, Text, View } from "react-native";
import { GlobalColors } from "../style/colors";
import { GlobalStrings } from "../utils/constants";
import Entry from "./UI/Entry";
import Button from "./UI/Button";
import { useState } from "react";

const INPUT_INIT = {
  user: {
    value: "jair@jair.com",
    isValid: true,
  },
  password: {
    value: "jair",
    isValid: true,
  },
};

const LoginForm = ({ onSubmit }) => {
  const [showErrorLabel, setShowErrorLabel] = useState(false);
  const [inputs, setInputs] = useState(INPUT_INIT);

  function inputChangedHandler(inputType, enteredText) {
    setInputs((prevState) => {
      return {
        ...prevState,
        [inputType]: { value: enteredText, isValid: true },
      };
    });
  }

  function validateEmail(email) {
    const emailRegex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
    return emailRegex.test(email);
  }

  async function submmitHanler() {
    setShowErrorLabel(false);
    const formData = {
      user: inputs.user.value,
      password: inputs.password.value,
    };

    const userIsValid =
      formData.user.trim().length > 0 && validateEmail(formData.user);
    const passwordIsValid = formData.password.trim().length > 0;

    if (userIsValid && passwordIsValid) {
      onSubmit(formData);
      return;
    }

    setShowErrorLabel(true);
    setInputs((prevState) => {
      return {
        user: { value: prevState.user.value, isValid: userIsValid },
        password: {
          value: prevState.password.value,
          isValid: passwordIsValid,
        },
      };
    });
  }

  return (
    <View style={loginStyles.container}>
      <Entry
        label={GlobalStrings.username}
        style={loginStyles.input}
        invalid={!inputs.user.isValid}
        textInputConfig={{
          onChangeText: (enteredText) =>
            inputChangedHandler("user", enteredText),
          value: inputs.user.value,
        }}
      />
      <Entry
        label={GlobalStrings.password}
        style={loginStyles.input}
        invalid={!inputs.password.isValid}
        textInputConfig={{
          secureTextEntry: true,
          onChangeText: (enteredText) =>
            inputChangedHandler("password", enteredText),
          value: inputs.password.value,
        }}
      />
      <Button style={loginStyles.button} onPress={submmitHanler}>
        {GlobalStrings.login}
      </Button>
      {showErrorLabel && (
        <Text style={loginStyles.errorLabel}>
          {GlobalStrings.emptyFieldMessage}
        </Text>
      )}
    </View>
  );
};

const loginStyles = StyleSheet.create({
  container: {
    width: "100%",
    paddingHorizontal: 20,
  },
  input: {
    marginTop: 10,
  },
  button: {
    marginTop: 20,
  },
  incorrect: {
    color: GlobalColors.red,
    textAlign: "center",
  },
  errorLabel: {
    marginTop: 10,
    color: GlobalColors.red,
    textAlign: "center",
    fontSize: 16,
  },
});

export default LoginForm;
