import { FlatList, StyleSheet, View } from "react-native";
import ItemList from "./ItemList";
import YesNoModal from "./YesNoModal";
import { useState } from "react";
import { GlobalStrings } from "../utils/constants";

const List = ({ items, loadMore, onSelect, onDelete }) => {
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [selectedId, setSelectedId] = useState("");
  
  function renderItems(itemData) {
    return (
      <ItemList
        {...itemData.item}
        onSelected={onSelectedHandler}
        onDelete={onDeleteConfirmationHandler}
      />
    );
  }

  function handleLoadMore() {
    // loadMore();
  }

  function onSelectedHandler(id) {
    onSelect(id);
  }

  function onDeleteConfirmationHandler(id) {
    setShowConfirmation(true);
    setSelectedId(id);
  }

  function onDeleteHandler(type) {
    setShowConfirmation(false);

    if (type === 1) {
      onDelete(selectedId);
    }
  }

  return (
    <View style={listStyle.container}>
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={renderItems}
        alwaysBounceVertical={false}
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.5}
      />
      <YesNoModal
        visible={showConfirmation}
        title={GlobalStrings.deleteConfirmationTitle}
        message={GlobalStrings.deleteConformationMessage}
        acceptTitle={GlobalStrings.accept}
        cancelTitle={GlobalStrings.cancel}
        onSubmit={onDeleteHandler}
      />
    </View>
  );
};

const listStyle = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default List;
