import { Modal, Pressable, StyleSheet, Text, View } from "react-native";
import { GlobalColors } from "../style/colors";
import IconButton from "./UI/IconButton";
import YesNoModal from "./YesNoModal";
import { useState } from "react";

const ItemList = ({ id, name, alpha_3, onSelected, onDelete }) => {
  function onSelectedHandler() {
    onSelected(id);
  }

  function onDeleteHandler() {
    onDelete(id);
  }

  return (
    <>
      <Pressable
        onPress={onSelectedHandler}
        style={({ pressed }) => pressed && itemListStyle.pressed}
      >
        <View style={itemListStyle.container}>
          <View>
            <Text style={itemListStyle.textTitle}>{name}</Text>
            {alpha_3 && (
              <Text style={itemListStyle.textDescription}>{alpha_3}</Text>
            )}
          </View>
          <View style={itemListStyle.iconContainer}>
            <IconButton
              icon="trash"
              color={GlobalColors.red}
              size={24}
              onPress={onDeleteHandler}
            />
          </View>
        </View>
      </Pressable>
    </>
  );
};

const itemListStyle = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 10,
    marginVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: GlobalColors.primary,
  },
  iconContainer: {
    justifyContent: "center",
  },
  textTitle: {
    fontSize: 18,
    fontFamily: "open-sans-bold",
  },
  textDescription: {
    fontSize: 16,
    fontFamily: "open-sans",
  },
  pressed: {
    opacity: 0.75,
  },
});

export default ItemList;
