import { Modal, StyleSheet, Text, View } from "react-native";
import Entry from "./UI/Entry";
import Button from "./UI/Button";
import { useEffect, useState } from "react";

const StatesModal = ({
  title,
  labelEntry,
  acceptTitle,
  cancelTitle,
  visible,
  onSubmit,
  idState,
  initValue,
}) => {
  const [inputs, setInputs] = useState({
    name: {
      value: "",
      isValid: true,
    },
  });

  useEffect(() => {
    if (visible) {
      setInputs({
        name: {
          value: initValue,
          isValid: true,
        },
      });
    }
  }, [visible]);

  function onSubmitHandler(type) {
    if (type === 0) {
      onSubmit(type, {});
      return;
    }

    const formData = {
      id: idState,
      name: inputs.name.value,
    };

    const nameIsValid = formData.name.trim().length > 0;

    if (nameIsValid) {
      const typeReturn = initValue ? 1 : 2;
      onSubmit(typeReturn, formData);
      return;
    }

    setInputs((prevState) => {
      return {
        name: { value: prevState.name.value, isValid: nameIsValid },
      };
    });
  }

  function inputChangedHandler(inputType, enteredText) {
    setInputs((prevState) => {
      return {
        ...prevState,
        [inputType]: { value: enteredText, isValid: true },
      };
    });
  }

  return (
    <Modal
      transparent={true}
      animationType="none"
      visible={visible}
      onRequestClose={() => {}}
    >
      <View style={statesStyle.overlay}>
        <View style={statesStyle.container}>
          <Text style={statesStyle.title}>{title}</Text>
          <Entry
            label={labelEntry}
            style={statesStyle.nameInput}
            invalid={!inputs.name.isValid}
            textInputConfig={{
              onChangeText: (enteredText) =>
                inputChangedHandler("name", enteredText),
              value: inputs.name.value,
            }}
          />
          <View style={statesStyle.buttonContainer}>
            <View style={statesStyle.button}>
              <Button mode="flat" onPress={() => onSubmitHandler(0)}>
                {cancelTitle}
              </Button>
            </View>
            <View style={statesStyle.button}>
              <Button onPress={() => onSubmitHandler(1)}>{acceptTitle}</Button>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const statesStyle = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  container: {
    width: "100%",
    maxWidth: 300,
    padding: 20,
    backgroundColor: "white",
    borderRadius: 10,
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  title: {
    fontSize: 20,
    fontFamily: "open-sans-bold",
  },
  nameInput: {
    marginVertical: 10,
  },
  buttonContainer: {
    flexDirection: "row",
  },
  button: {
    flex: 1,
    marginHorizontal: 5,
  },
});

export default StatesModal;
