import { createContext, useContext, useReducer, useState } from "react";
import LoadingOverlay from "../components/LoadingOverlay";

const ApplicationContext = createContext({
  isAuth: false,
  countryStates: [],
  authenticated: () => {},
  showLoading: () => {},
  hideLoading: () => {},
  setStateList: (idCountry, states) => {},
  getStatesList: (idCountry) => {},
  createState: (idCountry, name) => {},
  updateState: (idCountry, idState, name) => {},
  deleteState: (idCountry, idState) => {},
});

export const useApplicationContext = () => useContext(ApplicationContext);

function statesReducer(state, action) {
  switch (action.type) {
    case "SET":
      const newItem = {
        idCountry: action.payload.idCountry,
        states: action.payload.stateList,
      };

      if (state.length === 0) {
        return [newItem];
      } else {
        const isAlreadyThere = state.find(
          (item) => item.idCountry === action.payload.idCountry
        );

        if (isAlreadyThere) {
          return state;
        }
      }

      return [...state, newItem];
    case "GET":
      return state;
    case "ADD":
      const addCountryIndex = state.findIndex(
        (item) => item.idCountry === action.payload.idCountry
      );

      const newState = { id: Math.round().toString(), name: action.payload.name };

      if (addCountryIndex < 0) {
        var newCountry = {
          idCountry: action.payload.idCountry,
          states: [newState],
        };

        return [...state, newCountry];
      }

      const addStateList = state[addCountryIndex].states;
      const addedItem = [...addStateList, newState];
      const addedCountry = [...state];
      addedCountry[addCountryIndex].states = addedItem;
      return addedCountry;
    case "PUT":
      const updatableCountryIndex = state.findIndex(
        (item) => item.idCountry === action.payload.idCountry
      );

      if (updatableCountryIndex < 0) {
        return state;
      }

      const countryItem = { ...state[updatableCountryIndex] };
      const updatableState = countryItem.states.find(
        (item) => item.id === action.payload.idState
      );

      if (!updatableState) {
        return state;
      }

      updatableState.name = action.payload.name;
      const updatedCountry = [...state];
      updatedCountry[updatableCountryIndex] = countryItem;
      return updatedCountry;
    case "DELETE":
      const countryToDeleteIndex = state.findIndex(
        (item) => item.idCountry === action.payload.idCountry
      );

      const storeListToDelete = state[countryToDeleteIndex].states.filter(
        (item) => item.id !== action.payload.idState
      );

      const countryToDelete = state[countryToDeleteIndex];
      const currentCountry = { ...countryToDelete };
      currentCountry.states = storeListToDelete;
      const cleanList = [...state];
      cleanList[countryToDeleteIndex] = currentCountry;
      return cleanList;
    default:
      return state;
  }
}

const ApplicationProvider = ({ children }) => {
  const [loading, setLoading] = useState(false);
  const [isAuth, setIsAuth] = useState(false);
  const [states, dispatchStates] = useReducer(statesReducer, []);

  function showLoading() {
    setLoading(true);
  }
  function hideLoading() {
    setLoading(false);
  }

  function authenticated() {
    setIsAuth(true);
  }

  function setStateList(idCountry, stateList) {
    dispatchStates({
      type: "SET",
      payload: { idCountry: idCountry, stateList: stateList },
    });
  }

  function getStatesList(idCountry) {
    dispatchStates({
      type: "GET",
      payload: idCountry,
    });
  }

  function createState(idCountry, name) {
    dispatchStates({
      type: "ADD",
      payload: { idCountry: idCountry, name: name },
    });
  }

  function updateState(idCountry, idState, name) {
    dispatchStates({
      type: "PUT",
      payload: { idCountry: idCountry, idState: idState, name: name },
    });
  }

  function deleteState(idCountry, idState) {
    dispatchStates({
      type: "DELETE",
      payload: { idCountry: idCountry, idState: idState },
    });
  }

  const value = {
    isAuth: isAuth,
    countryStates: states,
    authenticated: authenticated,
    showLoading: showLoading,
    hideLoading: hideLoading,
    setStateList: setStateList,
    getStatesList: getStatesList,
    createState: createState,
    updateState: updateState,
    deleteState: deleteState,
  };

  return (
    <ApplicationContext.Provider value={value}>
      {children}
      <LoadingOverlay visible={loading} />
    </ApplicationContext.Provider>
  );
};

export default ApplicationProvider;
