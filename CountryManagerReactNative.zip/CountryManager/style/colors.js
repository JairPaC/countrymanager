export const GlobalColors = {
    primary: "#512BD4",
    red: "#FB3753",
    success: "#609F3F",
    separatorColor: "#EEEEEE",
};