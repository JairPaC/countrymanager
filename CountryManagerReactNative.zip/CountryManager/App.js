// React
import { useEffect, useState } from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

// Helpers
import { StatusBar } from "expo-status-bar";
import Ionicons from "@expo/vector-icons/Ionicons";
import * as Font from "expo-font";
import * as SplashScreen from "expo-splash-screen";
import { NavigationContainer } from "@react-navigation/native";
import LoginScreen from "./screens/LoginScreen";
import { GlobalColors } from "./style/colors";
import ApplicationProvider, {
  useApplicationContext,
} from "./store/applicationContext";
import DashboardScreen from "./screens/DashboardScreen";
import DetailsScreen from "./screens/DetailsScreen";

SplashScreen.preventAutoHideAsync();
const stackNavigation = createNativeStackNavigator();

export default function App() {
  const [appIsReady, setAppIsReady] = useState(false);

  useEffect(() => {
    const loadFonts = async () => {
      try {
        await Font.loadAsync({
          // Add your custom fonts here
          "open-sans": require("./assets/fonts/OpenSans-Regular.ttf"),
          "open-sans-bold": require("./assets/fonts/OpenSans-Bold.ttf"),
        });

        setAppIsReady(true);
        await SplashScreen.hideAsync();
      } catch (e) {
        console.warn(e);
      }
    };

    loadFonts();
  }, []);

  if (!appIsReady) {
    return null;
  }

  function AuthenticateStack() {
    return (
      <stackNavigation.Navigator
        screenOptions={{
          contentStyle: { backgroundColor: GlobalColors.primary },
          headerTitleAlign: "center",
        }}
      >
        <stackNavigation.Screen
          name="Login"
          component={LoginScreen}
          options={{
            contentStyle: { backgroundColor: GlobalColors.primary },
            headerShown: false,
          }}
        />
      </stackNavigation.Navigator>
    );
  }

  function AuthenticatedStack() {
    return (
      <stackNavigation.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: GlobalColors.primary },
          headerTintColor: "white",
          contentStyle: { backgroundColor: "white" },
          headerTitleAlign: "center",
        }}
      >
        <stackNavigation.Screen name="Dashboard" component={DashboardScreen} />
        <stackNavigation.Screen name="Details" component={DetailsScreen} />
      </stackNavigation.Navigator>
    );
  }

  function Navigation() {
    const { isAuth } = useApplicationContext();

    return (
      <NavigationContainer>
        {!isAuth && <AuthenticateStack />}
        {isAuth && <AuthenticatedStack />}
      </NavigationContainer>
    );
  }

  return (
    <>
      <StatusBar style="auto" />
      <ApplicationProvider>
        <Navigation />
      </ApplicationProvider>
    </>
  );
}
