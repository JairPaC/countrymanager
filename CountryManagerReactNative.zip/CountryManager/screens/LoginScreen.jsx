import { Image, ScrollView, StyleSheet, Text, View } from "react-native";
import LoginForm from "../components/LoginForm";
import { useApplicationContext } from "../store/applicationContext";
import { GlobalStrings } from "../utils/constants";

const LoginScreen = () => {
  const { authenticated } = useApplicationContext();

  function onSubmitHandler(formData) {
    if (
      formData.user === GlobalStrings.correctUser &&
      formData.password === GlobalStrings.correctPassword
    ) {
      authenticated();
    }
  }

  return (
    <ScrollView contentContainerStyle={loginStyle.container}>
      <Image
        style={loginStyle.image}
        source={require("../assets/logoapp.png")}
      />
      <View style={loginStyle.entryContainer}>
        <LoginForm onSubmit={onSubmitHandler} />
      </View>
    </ScrollView>
  );
};

const loginStyle = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  entryContainer: {
    padding: 10,
    paddingBottom: 20,
    margin: 10,
    width: "100%",
    maxWidth: 300,
    backgroundColor: "white",
    borderRadius: 10,
  },
  image: {
    marginBottom: 30,
    height: 150,
    width: 150,
  },
});

export default LoginScreen;
