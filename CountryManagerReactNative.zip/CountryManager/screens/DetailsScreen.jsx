import { useEffect, useLayoutEffect, useState } from "react";
import { GlobalStrings } from "../utils/constants";
import { Alert, StyleSheet, Text, View } from "react-native";
import Entry from "../components/UI/Entry";
import Button from "../components/UI/Button";
import { useApplicationContext } from "../store/applicationContext";
import {
  createCountry,
  getCountry,
  getStates,
  updateCountry,
} from "../http/apiRequest";
import List from "../components/List";
import StatesModal from "../components/StatesModal";
import IconButton from "../components/UI/IconButton";
import { GlobalColors } from "../style/colors";

const INPUT_INIT = {
  name: {
    value: "",
    isValid: true,
  },
  alpha2: {
    value: "",
    isValid: true,
  },
  alpha3: {
    value: "",
    isValid: true,
  },
  code: {
    value: "",
    isValid: true,
  },
  iso: {
    value: "",
    isValid: true,
  },
};

const DetailsScreen = ({ route, navigation }) => {
  const {
    showLoading,
    hideLoading,
    getStatesList,
    setStateList,
    deleteState,
    updateState,
    createState,
    countryStates,
  } = useApplicationContext();
  const [inputs, setInputs] = useState(INPUT_INIT);
  const [states, setStates] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedState, setSelectedState] = useState();
  const idCountry = route.params?.idCountry;

  useLayoutEffect(() => {
    let title = GlobalStrings.details;

    if (idCountry === "") {
      title = GlobalStrings.newCountry;
    }

    navigation.setOptions({
      headerTitle: title,
    });
  }, [navigation]);

  useEffect(() => {
    async function fetchCountryInformation() {
      if (idCountry !== "") {
        try {
          showLoading();
          var countryResponse = await getCountry(idCountry);
          setInputs({
            name: {
              value: countryResponse.name,
              isValid: true,
            },
            alpha2: {
              value: countryResponse.alpha_2,
              isValid: true,
            },
            alpha3: {
              value: countryResponse.alpha_3,
              isValid: true,
            },
            code: {
              value: countryResponse.code,
              isValid: true,
            },
            iso: {
              value: countryResponse.iso_3166_2,
              isValid: true,
            },
          });

          getStatesList(idCountry);
          const country = countryStates.find(
            (item) => item.idCountry === idCountry
          );

          if (!country || !country.states || country.states.length === 0) {
            var statesResponse = await getStates(idCountry);
            setStateList(idCountry, statesResponse);
            setStates(statesResponse);
          } else {
            setStates(country.states);
          }
        } catch (error) {
          Alert.alert(
            GlobalStrings.apiErrorTitle,
            GlobalStrings.apirErrorMessage
          );
        } finally {
          hideLoading();
        }
      }
    }

    fetchCountryInformation();
  }, [idCountry]);

  useEffect(() => {
    if (idCountry !== "" && countryStates) {
      var stateList = countryStates.find(
        (item) => item.idCountry === idCountry
      );

      if (stateList) {
        setStates(stateList.states);
      }
    }
  }, [idCountry, countryStates]);

  function inputChangedHandler(inputType, enteredText) {
    setInputs((prevState) => {
      return {
        ...prevState,
        [inputType]: { value: enteredText, isValid: true },
      };
    });
  }

  async function onSubmitHandler() {
    const formData = {
      id: idCountry,
      name: inputs.name.value,
      alpha2: inputs.alpha2.value,
      alpha3: inputs.alpha3.value,
      code: inputs.code.value,
      iso: inputs.iso.value,
    };

    const nameIsValid = formData.name.trim().length > 0;
    const alpha2IsValid = formData.alpha2.trim().length > 0;
    const alpah3IsValid = formData.alpha3.trim().length > 0;
    const codeIsValid = formData.code.trim().length > 0;
    const isoisValid = formData.iso.trim().length > 0;

    if (
      nameIsValid &&
      alpha2IsValid &&
      alpah3IsValid &&
      codeIsValid &&
      isoisValid
    ) {
      try {
        showLoading();

        if (idCountry === "") {
          await createCountry(formData);
        } else {
          await updateCountry(formData);
        }

        hideLoading();
        navigation.goBack();
      } catch (error) {
        hideLoading();
      }
      return;
    }

    setInputs((prevState) => {
      return {
        name: { value: prevState.name.value, isValid: nameIsValid },
        alpha2: { value: prevState.alpha2.value, isValid: alpha2IsValid },
        alpha3: { value: prevState.alpha3.value, isValid: alpah3IsValid },
        code: { value: prevState.code.value, isValid: codeIsValid },
        iso: { value: prevState.iso.value, isValid: isoisValid },
      };
    });
  }

  function onDeleteHandler(id) {
    showLoading();
    deleteState(idCountry, id);
    hideLoading();
  }

  function onStateAddHandler() {
    setSelectedState();
    setShowModal(true);
  }

  function onUpdateHanlder(id) {
    const state = countryStates
      .find((item) => item.idCountry === idCountry)
      .states.find((item) => item.id === id);

    if (state) {
      setSelectedState(state);
    }
    setShowModal(true);
  }

  function onStateSubmitHandler(type, formData) {
    setShowModal(false);
    showLoading();
    if (type === 1) {
      updateState(idCountry, formData.id, formData.name);
    } else {
      createState(idCountry, formData.name);
    }
    hideLoading();
  }

  return (
    <>
      <View style={detailStyle.container}>
        <Entry
          label={GlobalStrings.name}
          style={detailStyle.nameInput}
          invalid={!inputs.name.isValid}
          textInputConfig={{
            onChangeText: (enteredText) =>
              inputChangedHandler("name", enteredText),
            value: inputs.name.value,
          }}
        />
        <View style={detailStyle.rowContainer}>
          <Entry
            label={GlobalStrings.alpha_2}
            style={detailStyle.rowInpuLeft}
            invalid={!inputs.alpha2.isValid}
            textInputConfig={{
              maxLength: 2,
              onChangeText: (enteredText) =>
                inputChangedHandler("alpha2", enteredText),
              value: inputs.alpha2.value,
            }}
          />
          <Entry
            label={GlobalStrings.alpha_3}
            style={detailStyle.rowInpuRight}
            invalid={!inputs.alpha3.isValid}
            textInputConfig={{
              maxLength: 3,
              onChangeText: (enteredText) =>
                inputChangedHandler("alpha3", enteredText),
              value: inputs.alpha3.value,
            }}
          />
        </View>
        <View style={detailStyle.rowContainer}>
          <Entry
            label={GlobalStrings.code}
            style={detailStyle.rowInpuLeft}
            invalid={!inputs.code.isValid}
            textInputConfig={{
              keyboardType: "decimal-pad",
              onChangeText: (enteredText) =>
                inputChangedHandler("code", enteredText),
              value: inputs.code.value,
            }}
          />
          <Entry
            label={GlobalStrings.iso}
            style={detailStyle.rowInpuRight}
            invalid={!inputs.iso.isValid}
            textInputConfig={{
              onChangeText: (enteredText) =>
                inputChangedHandler("iso", enteredText),
              value: inputs.iso.value,
            }}
          />
        </View>
        {idCountry !== "" && (
          <View style={detailStyle.listContainer}>
            <IconButton
              icon="add"
              size={24}
              color={GlobalColors.primary}
              onPress={onStateAddHandler}
            />
            <List
              items={states}
              onSelect={onUpdateHanlder}
              onDelete={onDeleteHandler}
            />
          </View>
        )}
        <View style={detailStyle.buttonContainer}>
          <Button onPress={onSubmitHandler}>{GlobalStrings.save}</Button>
        </View>
        <StatesModal
          visible={showModal}
          title={
            selectedState ? GlobalStrings.updateState : GlobalStrings.addState
          }
          labelEntry={GlobalStrings.name}
          acceptTitle={GlobalStrings.save}
          cancelTitle={GlobalStrings.cancel}
          idState={selectedState && selectedState.id}
          initValue={selectedState && selectedState.name}
          onSubmit={onStateSubmitHandler}
        />
      </View>
    </>
  );
};

const detailStyle = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  rowContainer: {
    flexDirection: "row",
  },
  listContainer: {
    flex: 1,
  },
  nameInput: {
    marginVertical: 10,
  },
  rowInpuLeft: {
    flex: 1,
    marginRight: 5,
  },
  rowInpuRight: {
    flex: 1,
    marginLeft: 5,
  },
  buttonContainer: {
    justifyContent: "flex-end",
  },
});

export default DetailsScreen;
