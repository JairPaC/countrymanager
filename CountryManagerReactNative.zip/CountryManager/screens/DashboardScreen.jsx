import { useEffect, useLayoutEffect, useState } from "react";
import { Alert, StyleSheet, Text, View } from "react-native";

import { GlobalStrings } from "../utils/constants";
import IconButton from "../components/UI/IconButton";
import { getCountries } from "../http/apiRequest";
import { useApplicationContext } from "../store/applicationContext";
import List from "../components/List";

const DashboardScreen = ({ navigation }) => {
  const { showLoading, hideLoading } = useApplicationContext();
  const [filter, setFilter] = useState({ page: 1, limit: 100 });
  const [countries, setCountries] = useState([]);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: ({ tintColor }) => {
        return (
          <IconButton
            icon="add"
            color={tintColor}
            size={24}
            onPress={onAddHandler}
          />
        );
      },
    });
  }, [navigation]);

  useEffect(() => {
    const fetchCountries = async () => {
      try {
        showLoading();
        const response = await getCountries(filter.page, filter.limit);
        setCountries(response);
      } catch (error) {
        Alert.alert(
          GlobalStrings.apiErrorTitle,
          GlobalStrings.apirErrorMessage
        );
      } finally {
        hideLoading();
      }
    };

    fetchCountries();
  }, []);

  function onAddHandler() {
    navigation.navigate("Details", { idCountry: "" });
  }

  function onDeleteHandler(id) {
    console.log(id);
  }

  function onUpdateHanlder(id) {
    navigation.navigate("Details", { idCountry: id });
  }

  return (
    <View style={dashboardStyle.container}>
      <Text style={dashboardStyle.title}>{GlobalStrings.allCountries}</Text>
      <List
        items={countries}
        onSelect={onUpdateHanlder}
        onDelete={onDeleteHandler}
      />
    </View>
  );
};

const dashboardStyle = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  title: {
    fontSize: 24,
    textAlign: "center",
    fontFamily: "open-sans-bold",
  },
});

export default DashboardScreen;
