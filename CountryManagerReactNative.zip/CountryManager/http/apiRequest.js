import axios from "axios";

const BASE_URL = "https://api-exam.tsc-dev.xyz/";

export async function getCountries(page, limit) {
  const response = await axios.get(
    `${BASE_URL}countries?page=${page}&limit=${limit}`
  );

  if (response.status === 200 && response.data) {
    return response.data.records;
  }
  return [];
}

export async function getCountry(idCountry) {
  const response = await axios.get(`${BASE_URL}countries/${idCountry}`);
  return response.data;
}

export async function getStates(idCountry) {
  const response = await axios.get(`${BASE_URL}countries/${idCountry}/states`);
  return response.data;
}

export function createCountry(formData) {
  return axios.post(`${BASE_URL}countries`, formData);
}

export function updateCountry(formData) {
  return axios.put(`${BASE_URL}countries/${formData.id}`, formData);
}
