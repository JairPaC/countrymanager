﻿namespace CountryManager.Helper
{
    public class FAIcons
	{
        public const string Eye = "\uf06e";
        public const string EyeSlash = "\uf070";
        public const string CircleCheck = "\uf058";
        public const string CircleExclamation = "\uf06a";
        public const string Trash = "\uf1f8";
    }
}

