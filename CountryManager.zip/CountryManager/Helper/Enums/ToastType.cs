﻿namespace CountryManager.Helper.Enums
{
    public enum ToastType
	{
        Success,
        Error
    }
}

