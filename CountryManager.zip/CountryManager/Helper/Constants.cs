﻿namespace CountryManager.Helper
{
    public static class Constants
	{
        // URLs
        public const string APIUrl = "https://api-exam.tsc-dev.xyz";

        // Login information.
        public const string Username = "test@domain.com";
        public const string Password = "abc123";

        // Navigation Keys
        public const string CountryIdKey = "country_id";
        public const string IsSuccessKey = "Success";
    }
}

