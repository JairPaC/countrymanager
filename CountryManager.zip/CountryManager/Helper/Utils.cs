﻿using System;
using System.Text.RegularExpressions;

namespace CountryManager.Helper
{
	public static class Utils
	{
        #region Public Methods
        /// <summary>
        /// Validating email.
        /// </summary>
        /// <param name="email">String to validate.</param>
        public static bool IsEmailValid(string email)
        {
            bool isEmail = Regex.IsMatch(email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            return isEmail;
        }

        /// <summary>
        /// Validating Connection.
        /// </summary>
        /// <returns></returns>
        public static bool IsInternetConnected()
        {
            var currentConnection = Connectivity.NetworkAccess;

            if (currentConnection == NetworkAccess.Internet)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion
    }
}

