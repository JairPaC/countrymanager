﻿using CountryManager.Models;

namespace CountryManager.Services
{
    public interface INavigationService
    {
        /// <summary>
        /// Sets the Root Navigation from the navigation stack.
        /// </summary>
        /// <param name="viewModel">The ViewModel for the Root.</param>
        /// <param name="parameter">The parameters for the RootPage.</param>
        void RootNavigation(Type viewModel, NavigationParameters? parameter = null);

        /// <summary>
        /// Asynchronously adds a <see cref="T:Xamarin.Forms.Page" /> to the top of the navigation stack, with optional animation.
        /// </summary>
        /// <param name="viewModel">The ViewModel to push.</param>
        /// <param name="animated">Whether to animate the push.</param>
        /// <param name="parameter">The parameters for the push.</param>
        /// <returns>A task that represents the asynchronous push operation.</returns>
        Task PushAsync(Type viewModel, bool animated = true, NavigationParameters? parameter = null);

        /// <summary>
        /// Goes to previous page.
        /// </summary>
        Task GoBack(NavigationParameters? parameter = null, bool animated = true);

        /// <summary>
        /// Remove previous page.
        /// </summary>
        void RemovePreviousPage();

        /// <summary>
        /// Asynchronously adds a <see cref="T:Xamarin.Forms.View" /> to the top of the navigation stack, with optional animation.
        /// </summary>
        /// <param name="viewModel">The ViewModel to push.</param>
        /// <param name="parameter">The parameters for the push.</param>
        View GetViewToPush(Type viewModel, NavigationParameters? parameter = null);
    }
}