﻿using CountryManager.Controls.Enums;
using Mopups.Pages;

namespace CountryManager.Services
{
    public interface IDialogService
	{
        /// <summary>
        /// Show loading popup modal.
        /// </summary>
        Task ShowLoading(string message = "");

        /// <summary>
        /// Hide loading popup modal.
        /// </summary>
        Task HideLoading();

        /// <summary>
        /// Open Popup from MCT.
        /// </summary>
        Task OpenPopUp(PopupPage page);

        /// <summary>
        /// Close Popup from MCT.
        /// </summary>
        Task GoBackPopUpPage();

        /// <summary>
        /// Displays the yes no alert.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="message">The message.</param>
        /// <param name="accept">The accept.</param>
        /// <param name="cancel">The cancel.</param>
        /// <returns></returns>
        Task<bool> DisplayYesNoAlert(string title, string message, string accept = "OK", string cancel = "CANCEL");

        /// <summary>
        /// Displays the ok alert.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="message">The message.</param>
        /// <returns></returns>
        Task DisplayYesNoAlert(string title, string message, string firstButtonText = "", string secondButtonText = "", ModalButtonType firstButtonType = ModalButtonType.Secondary, ModalButtonType secondButtonType = ModalButtonType.Primary, Action? task = null);

        /// <summary>
        /// Displays the ok alert.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="message">The message.</param>
        /// <param name="buttonText">Button text.</param>
        Task DisplayOkAlert(string title, string message, string buttonText = "");
    }
}

