﻿using System.Diagnostics;
using System.Net;
using CountryManager.Helper;
using CountryManager.Models;
using CountryManager.Services.API;
using Refit;

namespace CountryManager.Services.Implementation
{
    public class CloudRestService : ICloudRestService
    {
        #region Readonly Properties
        private IApplicationAPIService _applicationAPIService;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor of <see cref="CloudRestService"/> class.
        /// </summary>
        public CloudRestService()
        {
            _applicationAPIService = RestService.For<IApplicationAPIService>(Constants.APIUrl);
        }
        #endregion

        #region Countries
        /// <summary>
        /// Get all countries.
        /// </summary>
        /// <param name="page">Page number.</param>
        /// <param name="limit">Limit per page.</param>
        /// <returns>List of countries.</returns>
        public async Task<CountriesResponseDto> GetAllCountries(int page, int limit)
        {
            try
            {
                if (Utils.IsInternetConnected())
                {
                    return await _applicationAPIService.GetAllCountries(page, limit);
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
#if DEBUG
                Debug.Write($"{nameof(GetAllCountries)} - {ex.Message}");
#endif
                return null;
            }
        }

        /// <summary>
        /// Get Country.
        /// </summary>
        /// <param name="countryId">Country Id.</param>
        /// <returns>List of countries.</returns>
        public async Task<CountryDto> GetCountry(int countryId)
        {
            try
            {
                if (Utils.IsInternetConnected())
                {
                    return await _applicationAPIService.GetCountry(countryId);
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
#if DEBUG
                Debug.Write($"{nameof(GetAllCountries)} - {ex.Message}");
#endif
                return null;
            }
        }

        /// <summary>
        /// Create country.
        /// </summary>
        /// <param name="country">Country DTO</param>
        /// <returns>Country Identifier.</returns>
        public async Task<int?> CreateCountry(CountryDto country)
        {
            try
            {
                if (Utils.IsInternetConnected())
                {
                    var response = await _applicationAPIService.CreateCountry(country);
                    var respString = await response.Content.ReadAsStringAsync();
                    var isSuccess = response.EnsureSuccessStatusCode();

                    if (isSuccess.StatusCode == HttpStatusCode.OK && respString !=  null)
                    {
                        return int.Parse(respString);
                    }

                    return null;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
#if DEBUG
                Debug.Write($"{nameof(GetAllCountries)} - {ex.Message}");
#endif
                return null;
            }
        }

        /// <summary>
        /// Update country.
        /// </summary>
        /// <param name="country">Country DTO</param>
        public async Task<bool> UpdateCountry(CountryDto country)
        {
            try
            {
                if (Utils.IsInternetConnected())
                {
                    var response = await _applicationAPIService.UpdateCountry(country, country.Id);
                    var respString = await response.Content.ReadAsStringAsync();
                    var isSuccess = response.EnsureSuccessStatusCode();

                    if (isSuccess.StatusCode == HttpStatusCode.OK && respString != null)
                    {
                        return true;
                    }

                    return false;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
#if DEBUG
                Debug.Write($"{nameof(GetAllCountries)} - {ex.Message}");
#endif
                return false;
            }
        }

        /// <summary>
        /// Delete country.
        /// </summary>
        /// <param name="countryId">Countr Id.</param>
        /// <returns>Message.</returns>
        public async Task<string> DeleteCountry(int countryId)
        {
            try
            {
                if (Utils.IsInternetConnected())
                {
                    var response = await _applicationAPIService.DeleteCountry(countryId);
                    var respString = await response.Content.ReadAsStringAsync();
                    var isSuccess = response.EnsureSuccessStatusCode();

                    if (isSuccess.StatusCode == HttpStatusCode.OK && respString != null)
                    {
                        return "success";
                    }
                    else if (isSuccess.StatusCode == HttpStatusCode.NotFound)
                    {
                        return "Not Found";
                    }

                    return "error";
                }
                else
                {
                    return "error";
                }
            }
            catch (Exception ex)
            {
#if DEBUG
                Debug.Write($"{nameof(GetAllCountries)} - {ex.Message}");
#endif
                return "error";
            }
        }
        #endregion

        #region States
        /// <summary>
        /// Get all states by Country.
        /// </summary>
        /// <param name="countryId">Country Id.</param>
        /// <returns>List of states.</returns>
        public async Task<List<StateDto>> GetStates(int countryId)
        {
            try
            {
                if (Utils.IsInternetConnected())
                {
                    return await _applicationAPIService.GetStates(countryId);
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
#if DEBUG
                Debug.Write($"{nameof(GetAllCountries)} - {ex.Message}");
#endif
                return null;
            }
        }

        /// <summary>
        /// Delete state.
        /// </summary>
        /// <param name="countryId">Country Id.</param>
        /// <param name="stateId">State Id.</param>
        /// <returns>HTTP Response.</returns>
        public async Task<string> DeleteState(int countryId, int stateId)
        {
            try
            {
                if (Utils.IsInternetConnected())
                {
                    var response = await _applicationAPIService.DeleteState(countryId, stateId);
                    var respString = await response.Content.ReadAsStringAsync();
                    var isSuccess = response.EnsureSuccessStatusCode();

                    if (isSuccess.StatusCode == HttpStatusCode.OK && respString != null)
                    {
                        return "success";
                    }
                    else if (isSuccess.StatusCode == HttpStatusCode.NotFound)
                    {
                        return "Not Found";
                    }

                    return "error";
                }
                else
                {
                    return "error";
                }
            }
            catch (Exception ex)
            {
#if DEBUG
                Debug.Write($"{nameof(GetAllCountries)} - {ex.Message}");
#endif
                return "error";
            }
        }
        #endregion
    }
}

