﻿using CountryManager.Models;
using CountryManager.ViewModels.Base;

namespace CountryManager.Services.Implementation
{
    public class NavigationService : INavigationService
	{
        #region Private Properties
        private IAppContainer _appContainer;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor of <see cref="NavigationService"/> class.
        /// </summary>
        public NavigationService()
        {
            _appContainer = AppContainer.Instance;
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Sets the Root Navigation from the navigation stack.
        /// </summary>
        /// <param name="viewModel">The ViewModel for the Root.</param>
        /// <param name="parameter">The parameters for the RootPage.</param>
        public void RootNavigation(Type viewModel, NavigationParameters? parameter = null)
        {
            Application.Current.MainPage = CreateAndBindPage(viewModel, parameter);
        }

        /// <summary>
        /// Asynchronously adds a <see cref="T:Xamarin.Forms.Page" /> to the top of the navigation stack, with optional animation.
        /// </summary>
        /// <param name="viewModel">The ViewModel to push.</param>
        /// <param name="animated">Whether to animate the push.</param>
        /// <param name="parameter">The parameters for the push.</param>
        /// <returns>A task that represents the asynchronous push operation.</returns>
        public async Task PushAsync(Type viewModel, bool animated = true, NavigationParameters? parameter = null)
        {
            await Application.Current.MainPage.Navigation.PushAsync(CreateAndBindPage(viewModel, parameter), animated);
        }

        /// <summary>
        /// Goes to previous page.
        /// </summary>
        public async Task GoBack(NavigationParameters? parameter = null, bool animated = true)
        {
            await Application.Current.MainPage.Navigation.PopAsync(animated);

            if (parameter != null)
            {
                var navigationPage = Application.Current.MainPage as NavigationPage;

                if (navigationPage != null)
                {
                    var currentPage = navigationPage.CurrentPage;

                     if (currentPage.BindingContext is BaseViewModel vm)
                    {
                        vm.OnGoingBack(parameter);
                    }
                }
            }
        }

        /// <summary>
        /// Remove previous page.
        /// </summary>
        public void RemovePreviousPage()
        {
            Application.Current.MainPage.Navigation.RemovePage(Application.Current.MainPage.Navigation.NavigationStack[Application.Current.MainPage.Navigation.NavigationStack.Count - 2]);
        }

        /// <summary>
        /// Asynchronously adds a <see cref="T:Xamarin.Forms.View" /> to the top of the navigation stack, with optional animation.
        /// </summary>
        /// <param name="viewModel">The ViewModel to push.</param>
        /// <param name="parameter">The parameters for the push.</param>
        public View GetViewToPush(Type viewModel, NavigationParameters parameter)
        {
            return CreateAndBindView(viewModel, parameter);
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Creates and bind the page.
        /// </summary>
        /// <param name="viewModelType">ViewModel Type</param>
        /// <param name="parameter">Parameters</param>
        /// <returns>Returns a object that represents a <see cref="Page"/>.</returns>
        private Page CreateAndBindPage(Type viewModelType, NavigationParameters? parameter = null)
        {
            Type pageType = _appContainer.GetPageTypeForViewModel(viewModelType);

            if (pageType == null)
            {
                throw new Exception($"Cannot locate page type for {viewModelType}");
            }

            Page page = Activator.CreateInstance(pageType) as Page;
            var viewModel = AppContainer.Instance.Resolve(viewModelType);

            if (viewModel != null)
            {
                if (viewModel is BaseViewModel ViewModel)
                {
                    ViewModel.Init();

                    if (parameter != null)
                    {
                        ViewModel.OnInit(parameter);
                    }

                    page.BindingContext = viewModel;
                    page.Disappearing += (object sender, EventArgs e) => { ViewModel.OnDisappearing(); };
                }
            }

            return page;
        }

        /// <summary>
        /// Creates and bind the Content View.
        /// </summary>
        /// <param name="viewModelType">ViewModel Type</param>
        /// <param name="parameter">Parameters</param>
        /// <returns>Returns a object that represents a <see cref="ContentView"/>.</returns>
        private View CreateAndBindView(Type viewModelType, NavigationParameters? parameter = null)
        {
            Type pageType = _appContainer.GetPageTypeForViewModel(viewModelType);

            if (pageType == null)
            {
                throw new Exception($"Cannot locate page type for {viewModelType}");
            }

            View page = Activator.CreateInstance(pageType) as View;
            var viewModel = AppContainer.Instance.Resolve(viewModelType);

            if (viewModel != null)
            {
                if (viewModel is BaseViewModel ViewModel)
                {
                    ViewModel.Init();

                    if (parameter != null)
                    {
                        ViewModel.OnInit(parameter);
                    }
                }

                page.BindingContext = viewModel;
            }

            return page;
        }
        #endregion
    }
}

