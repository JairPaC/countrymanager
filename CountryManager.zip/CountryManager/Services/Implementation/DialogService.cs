﻿using System.Diagnostics;
using CountryManager.Controls.Enums;
using CountryManager.Resx;
using CountryManager.Views.Modals;
using Mopups.Pages;
using Mopups.Services;

namespace CountryManager.Services.Implementation
{
    public class DialogService : IDialogService
    {
        #region Constructor
        /// <summary>
        /// Constructor of <see cref="DialogService"/> class.
        /// </summary>
        public DialogService()
        {
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Show loading popup modal.
        /// </summary>
        public async Task ShowLoading(string message = "")
        {
            var loadingReference = new LoadingModal();

            if (string.IsNullOrEmpty(message))
            {
                message = AppResources.PleaseWaitMessage;
            }

            loadingReference.LoadingMessage = message;
            await MopupService.Instance.PushAsync(loadingReference);
            await Task.Delay(500);
        }

        /// <summary>
        /// Hide loading popup modal.
        /// </summary>
        public async Task HideLoading()
        {
            // Remove only the loading modals.
            if (MopupService.Instance.PopupStack.Any())
            {
                foreach (var page in MopupService.Instance.PopupStack.ToList())
                {
                    if (page is LoadingModal load)
                    {
                        await MopupService.Instance.RemovePageAsync(load);
                    }
                }
            }
        }

        /// <summary>
        /// Open Popup from MCT.
        /// </summary>
        public async Task OpenPopUp(PopupPage page)
        {
            try
            {
                await HideLoading();
                await MopupService.Instance.PushAsync(page);
            }
            catch (Exception ex)
            {
#if DEBUG
                Debug.WriteLine($"Soruce: {ex.Source}\n Message: {ex.Message}\n StackTrace: {ex.StackTrace}");
#endif
            }
        }

        /// <summary>
        /// Close Popup from MCT.
        /// </summary>
        public async Task GoBackPopUpPage()
        {
            try
            {
                if (MopupService.Instance.PopupStack.Any())
                    await MopupService.Instance.PopAsync();
            }
            catch (Exception ex)
            {
#if DEBUG
                Debug.WriteLine($"Soruce: {ex.Source}\n Message: {ex.Message}\n StackTrace: {ex.StackTrace}");
#endif
            }
        }

        /// <summary>
        /// Displays the yes no alert.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="message">The message.</param>
        /// <param name="accept">The accept.</param>
        /// <param name="cancel">The cancel.</param>
        /// <returns></returns>
        public async Task<bool> DisplayYesNoAlert(string title, string message, string accept = "OK", string cancel = "CANCEL")
        {
            await HideLoading();
            Page mainPage = Application.Current?.MainPage ?? throw new NullReferenceException();
            return await mainPage.DisplayAlert(message, title, accept, cancel);
        }

        /// <summary>
        /// Displays the ok alert.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="message">The message.</param>
        /// <returns></returns>
        public async Task DisplayYesNoAlert(string title, string message, string firstButtonText = "", string secondButtonText = "", ModalButtonType firstButtonType = ModalButtonType.Secondary, ModalButtonType secondButtonType = ModalButtonType.Primary, Action? task = null)
        {
            await HideLoading();
            var page = new YesNoCustomModal();
            page.TitleModal = title;
            page.Message = message;
            page.FirstButtonText = string.IsNullOrEmpty(firstButtonText) ? AppResources.OK : firstButtonText;
            page.SecondButtonText = string.IsNullOrEmpty(secondButtonText) ? AppResources.Cancel : secondButtonText;
            page.FirstButtonType = firstButtonType;
            page.SecondButtonType = secondButtonType;
            page.SecondButtonCommand = new Command(task);
            await MopupService.Instance.PushAsync(page);
        }

        /// <summary>
        /// Displays the ok alert.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="message">The message.</param>
        /// <param name="buttonText">Button text.</param>
        public async Task DisplayOkAlert(string title, string message, string buttonText = "")
        {
            await HideLoading();
            Page mainPage = Application.Current?.MainPage ?? throw new NullReferenceException();
            await mainPage.DisplayAlert(title, message, string.IsNullOrEmpty(buttonText) ? AppResources.OK : buttonText);
        }
        #endregion
    }
}

