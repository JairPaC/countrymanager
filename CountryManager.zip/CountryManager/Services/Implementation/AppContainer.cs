﻿using System;
using System.Linq.Expressions;
using CountryManager.ViewModels;
using CountryManager.Views;
using DryIoc;

namespace CountryManager.Services.Implementation
{
	public class AppContainer : IAppContainer
    {
        #region Private Properties
        /// <summary>
        /// IoC Container
        /// </summary>
        private static DryIoc.IContainer _container;

        /// <summary>
        /// AppContainer Instance
        /// </summary>
        private static IAppContainer _instance;

        private Dictionary<Type, Type> mappings;
        #endregion

        #region Public Properties
        /// <summary>
        /// AppContainer Instance
        /// </summary>
        public static IAppContainer Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AppContainer();
                }

                return _instance;
            }
            set
            {
                if (value != null)
                {
                    _instance = value;
                }
            }
        }
        #endregion

        /// <summary>
        /// Class Constructor
        /// </summary>
        private AppContainer()
        {
            _container = new Container(rules => rules.WithDefaultIfAlreadyRegistered(IfAlreadyRegistered.Keep));
        }

        /// <summary>
        /// Register app dependencies
        /// </summary>
        public void RegisterDependencies()
        {
            mappings = new Dictionary<Type, Type>();

            // Services
            _container.Register<INavigationService, NavigationService>(Reuse.Singleton);
            _container.Register<IDialogService, DialogService>(Reuse.Singleton);
            _container.Register<ICloudRestService, CloudRestService>(Reuse.Singleton);

            // Views
            RegisterViewModelMapping(typeof(LoginViewModel), typeof(LoginPage));
            RegisterViewModelMapping(typeof(DashboardViewModal), typeof(DashboardViewModal));
            RegisterViewModelMapping(typeof(DetailsViewModel), typeof(DetailsPage));

            // VM Register
            _container.Register<LoginViewModel>();
            _container.Register<DashboardViewModal>();
            _container.Register<DetailsViewModel>();
        }

        /// <summary>
        /// Gets the Page Type from the ViewModel Type
        /// </summary>
        /// <param name="viewModelType">ViewModel Type</param>
        /// <returns>Returns a object that represents a <see cref="Type"/>.</returns>
        public Type GetPageTypeForViewModel(Type viewModelType)
        {
            if (!mappings.ContainsKey(viewModelType))
            {
                throw new KeyNotFoundException($"No map for ${viewModelType} was found on navigation mappings");
            }

            return mappings[viewModelType];
        }

        /// <summary>
        /// Get the registered instance
        /// </summary>
        /// <typeparam name="T">Instance Typeof</typeparam>
        /// <returns>Returns the registered instance.</returns>
        public T Resolve<T>()
        {
            return _container.Resolve<T>();
        }

        /// <summary>
        /// Get the registered instance
        /// </summary>
        /// <typeparam name="T">Instance Typeof</typeparam>
        /// <returns>Returns the registered instance.</returns>
        public T Resolve<T>(object serviceKey)
        {
            return _container.Resolve<T>(serviceKey);
        }

        /// <summary>
        /// Get the registered instance
        /// </summary>
        /// <param name="type">Instance type</param>
        /// <returns>Returns the registered instance.</returns>
        public object Resolve(Type type)
        {
            return _container.Resolve(type);
        }

        /// <summary>
        /// Registers an instance
        /// </summary>
        /// <typeparam name="TImplementation">Implementation Type</typeparam>
        public void Register<TImplementation>()
        {
            _container.Register<TImplementation>();
        }

        /// <summary>
        /// Registers an instance
        /// </summary>
        /// <typeparam name="TService">Interface Type</typeparam>
        /// <typeparam name="TImplementation">Implementation Type</typeparam>
        public void Register<TService, TImplementation>() where TImplementation : TService
        {
            _container.Register<TService, TImplementation>();
        }

        /// <summary>
        /// Registers an instance
        /// </summary>
        /// <typeparam name="TService">Interface Type</typeparam>
        /// <param name="expression">Used to specify the made expression.</param>
        public void Register<TService>(Expression<Func<TService>> expression)
        {
            _container.Register<TService>(Reuse.Singleton, Made.Of(expression));
        }

        /// <summary>
        /// Registers an instance
        /// </summary>
        /// <typeparam name="TService">Interface Type</typeparam>
        /// <typeparam name="TImplementation">Implementation Type</typeparam>
        public void RegisterSingleton<TService, TImplementation>() where TImplementation : TService
        {
            _container.Register<TService, TImplementation>(Reuse.Singleton);
        }

        /// <summary>
        /// Registers an instance
        /// </summary>
        /// <typeparam name="TService">Interface Type</typeparam>
        /// <param name="expression">Used to specify the made expression.</param>
        public void RegisterSingleton<TService>(Expression<Func<TService>> expression)
        {
            _container.Register<TService>(Reuse.Singleton, Made.Of(expression));
        }

        #region Private Methods
        /// <summary>
        /// Registers the ViewModel-View Mapping
        /// </summary>
        /// <param name="viewModel">Used to specify the ViewModel.</param>
        /// <param name="view">Used to specify the View.</param>
        private void RegisterViewModelMapping(Type viewModel, Type view)
        {
            if (!mappings.ContainsKey(viewModel))
            {
                mappings.Add(viewModel, view);
            }
        }
        #endregion
    }
}