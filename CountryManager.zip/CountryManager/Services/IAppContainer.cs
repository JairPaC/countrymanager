﻿using System.Linq.Expressions;

namespace CountryManager.Services
{
    public interface IAppContainer
    {
        /// <summary>
        /// Register Core Dependencies.
        /// </summary>
        void RegisterDependencies();

        /// <summary>
        /// Get the registered instance
        /// </summary>
        /// <typeparam name="T">Instance Typeof</typeparam>
        /// <returns>Returns the registered instance.</returns>
        T Resolve<T>();

        /// <summary>
        /// Get the registered instance
        /// </summary>
        /// <typeparam name="T">Instance Typeof</typeparam>
        /// <returns>Returns the registered instance.</returns>
        T Resolve<T>(object serviceKey);

        /// <summary>
        /// Get the registered instance
        /// </summary>
        /// <param name="type">Instance Typeof</param>
        /// <returns>Returns the registered instance.</returns>
        object Resolve(Type type);

        /// <summary>
        /// Registers an instance.
        /// </summary>
        /// <typeparam name="TImplementation">Implementation Type</typeparam>
        void Register<TImplementation>();

        /// <summary>
        /// Registers an instance.
        /// </summary>
        /// <typeparam name="TService">Interface Type</typeparam>
        /// <typeparam name="TImplementation">Implementation Type</typeparam>
        void Register<TService, TImplementation>() where TImplementation : TService;

        /// <summary>
        /// Registers an instance.
        /// </summary>
        /// <typeparam name="TService">Interface Type</typeparam>
        /// <typeparam name="TImplementation">Implementation Type</typeparam>
        void RegisterSingleton<TService, TImplementation>() where TImplementation : TService;

        /// <summary>
        /// Registers an instance
        /// </summary>
        /// <typeparam name="TService">Interface Type</typeparam>
        /// <param name="expression">Used to specify the made expression.</param>
        void RegisterSingleton<TService>(Expression<Func<TService>> expression);

        /// <summary>
        /// Gets the Page Type from the ViewModel Type
        /// </summary>
        /// <param name="viewModelType">ViewModel Type</param>
        /// <returns>Returns a object that represents a <see cref="Type"/>.</returns>
        Type GetPageTypeForViewModel(Type viewModelType);

    }
}