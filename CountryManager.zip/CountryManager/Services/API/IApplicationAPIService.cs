﻿using CountryManager.Models;
using Refit;

namespace CountryManager.Services.API
{
    [Headers("Content-Type: application/json")]
    public interface IApplicationAPIService
	{
        #region Countries
        /// <summary>
        /// Get all countries.
        /// </summary>
        /// <param name="page">Page number.</param>
        /// <param name="limit">Limit per page.</param>
        /// <returns>List of countries.</returns>
        [Get("/countries?page={page}&limit={limit}")]
        Task<CountriesResponseDto> GetAllCountries(int page, int limit);

        /// <summary>
        /// Get Country.
        /// </summary>
        /// <param name="countryId">Country Id.</param>
        /// <returns>List of countries.</returns>
        [Get("/countries/{countryId}")]
        Task<CountryDto> GetCountry(int countryId);

        /// <summary>
        /// Create country.
        /// </summary>
        /// <param name="country">Country DTO</param>
        /// <returns>Country Identifier.</returns>
        [Post("/countries")]
        Task<HttpResponseMessage> CreateCountry([Body]CountryDto country);

        /// <summary>
        /// Update country.
        /// </summary>
        /// <param name="country">Country DTO</param>
        [Put("/countries/{countryId}")]
        Task<HttpResponseMessage> UpdateCountry([Body]CountryDto country,int countryId);

        /// <summary>
        /// Delete country.
        /// </summary>
        /// <param name="countryId">Country Id.</param>
        /// <returns>HTTP Response.</returns>
        [Delete("/countries/{countryId}")]
        Task<HttpResponseMessage> DeleteCountry(int countryId);
        #endregion

        #region States
        /// <summary>
        /// Get all states by Country.
        /// </summary>
        /// <param name="countryId">Country Id.</param>
        /// <returns>List of states.</returns>
        [Get("/countries/{countryId}/states")]
        Task<List<StateDto>> GetStates(int countryId);

        /// <summary>
        /// Delete state.
        /// </summary>
        /// <param name="countryId">Country Id.</param>
        /// <param name="stateId">State Id.</param>
        /// <returns>HTTP Response.</returns>
        [Delete("/countries/{countryId}/states/{stateId}")]
        Task<HttpResponseMessage> DeleteState(int countryId, int stateId);
        #endregion
    }
}

