﻿using CountryManager.Models;

namespace CountryManager.Services
{
    public interface ICloudRestService
	{
        #region Countries
        /// <summary>
        /// Get all countries.
        /// </summary>
        /// <param name="page">Page number.</param>
        /// <param name="limit">Limit per page.</param>
        /// <returns>List of countries.</returns>
        Task<CountriesResponseDto> GetAllCountries(int page, int limit);

        /// <summary>
        /// Get Country.
        /// </summary>
        /// <param name="countryId">Country Id.</param>
        /// <returns>List of countries.</returns>
        Task<CountryDto> GetCountry(int countryId);

        /// <summary>
        /// Create country.
        /// </summary>
        /// <param name="country">Country DTO</param>
        /// <returns>Country Identifier.</returns>
        Task<int?> CreateCountry(CountryDto country);

        /// <summary>
        /// Update country.
        /// </summary>
        /// <param name="country">Country DTO</param>
        Task<bool> UpdateCountry(CountryDto country);

        /// <summary>
        /// Delete country.
        /// </summary>
        /// <param name="countryId">Countr Id.</param>
        /// <returns>Message.</returns>
        Task<string> DeleteCountry(int countryId);
        #endregion

        #region States
        /// <summary>
        /// Get all states by Country.
        /// </summary>
        /// <param name="countryId">Country Id.</param>
        /// <returns>List of states.</returns>
        Task<List<StateDto>> GetStates(int countryId);

        /// <summary>
        /// Delete state.
        /// </summary>
        /// <param name="countryId">Country Id.</param>
        /// <param name="stateId">State Id.</param>
        /// <returns>HTTP Response.</returns>
        Task<string> DeleteState(int countryId, int stateId);
        #endregion
    }
}

