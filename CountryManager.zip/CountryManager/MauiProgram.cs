﻿using CommunityToolkit.Maui;
using CountryManager.Controls.Base;
using Microsoft.Extensions.Logging;
using Microsoft.Maui.Controls.Compatibility.Hosting;
using Mopups.Hosting;

namespace CountryManager;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
            // Initialize the .NET MAUI Community Toolkit by adding the below line of code
            .UseMauiCommunityToolkit()
            .UseMauiCompatibility()
            .ConfigureMauiHandlers(handlers =>
            {
#if __ANDROID__
                handlers.AddCompatibilityRenderer(typeof(CustomEntryBase), typeof(Platforms.Android.Renderers.CustomEntryRenderer));
#elif IOS
                handlers.AddCompatibilityRenderer(typeof(CustomEntryBase), typeof(Platforms.iOS.Renderers.CustomEntryRenderer));
#endif
            })
            .ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
				fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                fonts.AddFont("FontAwesomeSolid.otf", "FAIcons");
            })
            .ConfigureMopups();

#if DEBUG
		builder.Logging.AddDebug();
#endif

        return builder.Build();
	}
}

