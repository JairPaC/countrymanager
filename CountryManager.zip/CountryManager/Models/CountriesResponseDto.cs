﻿using System.Text.Json.Serialization;

namespace CountryManager.Models
{
    public class CountriesResponseDto
	{
        [JsonPropertyName("current_page")]
        public int CurrentPage { get; set; }
        [JsonPropertyName("total_pages")]
        public int TotalPages { get; set; }
        [JsonPropertyName("records")]
        public List<CountryDto>? Countries { get; set; }
	}
}

