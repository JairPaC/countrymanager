﻿namespace CountryManager.Models
{
    public class NavigationParameters
	{
        #region Private Properties
        private Dictionary<string, object> _dictionary = new Dictionary<string, object>();
        #endregion

        #region Public Methods
        /// <summary>
        /// Add entry.
        /// </summary>
        /// <param name="key">Key value.</param>
        /// <param name="value">Value.</param>
        public void Add(string key, object value)
        {
            _dictionary.Add(key, value);
        }

        /// <summary>
        /// Remove entry.
        /// </summary>
        /// <param name="key">Key value.</param>
        public bool Remove(string key)
        {
            return _dictionary.Remove(key);
        }

        /// <summary>
        /// Try get value by key.
        /// </summary>
        /// <param name="key">Key value.</param>
        /// <param name="value">Value.</param>
        public bool ContainsKey(string key)
        {
            return _dictionary.ContainsKey(key);
        }

        /// <summary>
        /// Return value.
        /// </summary>
        /// <param name="key">Key value.</param>
        public object this[string key]
        {
            get => _dictionary[key];
            set => _dictionary[key] = value;
        }
        #endregion
    }
}

