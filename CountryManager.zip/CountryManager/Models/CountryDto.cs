﻿using System.Text.Json.Serialization;
using CommunityToolkit.Mvvm.ComponentModel;

namespace CountryManager.Models
{
    public class CountryDto : ObservableObject
    {
		public int Id { get; set; }
		public string Name { get; set; }
        [JsonPropertyName("alpha_2")]
        public string Alpha2 { get; set; }
        [JsonPropertyName("alpha_3")]
        public string Alpha3 { get; set; }
		public string Code { get; set; }
        [JsonPropertyName("iso_3166_2")]
        public string ISO { get; set; }
    }
}

