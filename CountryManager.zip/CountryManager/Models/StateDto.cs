﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace CountryManager.Models
{
    public class StateDto : ObservableObject
    {
		public int Id { get; set; }
		public string Name { get; set; }
	}
}

