﻿namespace CountryManager.Views;

public partial class DetailsPage : ContentPage
{
	#region Constructor
	/// <summary>
	/// Constructor of <see cref="DetailsPage"/> class.
	/// </summary>
	public DetailsPage()
	{
		InitializeComponent();
	}
	#endregion
}
