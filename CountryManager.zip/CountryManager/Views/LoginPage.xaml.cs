﻿using CountryManager.Services.Implementation;
using CountryManager.ViewModels;

namespace CountryManager.Views;

public partial class LoginPage : ContentPage
{
    #region Constructor
    /// <summary>
    /// Constructor of <see cref="LoginPage"/> class.
    /// </summary>
    public LoginPage()
    {
        InitializeComponent();
        BindingContext = AppContainer.Instance.Resolve(typeof(LoginViewModel));
    }
    #endregion
}