﻿namespace CountryManager.Views.Modals;

public partial class OperationsModal : ContentPage
{
	public OperationsModal()
	{
		InitializeComponent();
	}
}
