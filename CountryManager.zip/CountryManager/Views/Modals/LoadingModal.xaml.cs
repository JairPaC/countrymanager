﻿using Mopups.Pages;

namespace CountryManager.Views.Modals;

public partial class LoadingModal : PopupPage
{
    #region Bindable Properties
    /// <summary>
    /// The public static new readonly BindableProperty LoadingMessage property.
    /// </summary>
    public static readonly BindableProperty LoadingMessageProperty =
        BindableProperty.Create(nameof(LoadingMessage), typeof(string), typeof(LoadingModal), string.Empty);

    /// <summary>
    /// The public static new readonly BindableProperty LoadingMessage property.
    /// </summary>
    public string LoadingMessage
    {
        get => (string)GetValue(LoadingMessageProperty);
        set => SetValue(LoadingMessageProperty, value);
    }
    #endregion

    #region Constructor
    /// <summary>
    /// Constructor of <see cref="LoadingModal"/> class.
    /// </summary>
    public LoadingModal()
    {
        InitializeComponent();
    }
    #endregion
}
