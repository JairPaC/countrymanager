﻿using CountryManager.Controls.Enums;
using Mopups.Pages;
using Mopups.Services;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace CountryManager.Views.Modals;

public partial class YesNoCustomModal : PopupPage
{
    #region Public Properties
    public ICommand FirstButtonCommand => new Command(async () => await ClosePopup());
    public ICommand SecondButtonInternalCommand => new Command(async () => await InvokeSecondCommandPopup());
    #endregion

    #region Bindable Properties
    /// <summary>
    /// The public static new readonly BindableProperty TitleModal property.
    /// </summary>
    public static readonly BindableProperty TitleModalProperty =
        BindableProperty.Create(nameof(TitleModal), typeof(string), typeof(YesNoCustomModal), string.Empty);

    /// <summary>
    /// The public static new readonly BindableProperty TitleModal property.
    /// </summary>
    public string TitleModal
    {
        get => (string)GetValue(TitleModalProperty);
        set => SetValue(TitleModalProperty, value);
    }

    /// <summary>
    /// The public static new readonly BindableProperty Message property.
    /// </summary>
    public static readonly BindableProperty MessageProperty =
        BindableProperty.Create(nameof(Message), typeof(string), typeof(YesNoCustomModal), string.Empty);

    /// <summary>
    /// The public static new readonly BindableProperty Message property.
    /// </summary>
    public string Message
    {
        get => (string)GetValue(MessageProperty);
        set => SetValue(MessageProperty, value);
    }

    /// <summary>
    /// The public static new readonly BindableProperty FirstButtonText property.
    /// </summary>
    public static readonly BindableProperty FirstButtonTextProperty =
        BindableProperty.Create(nameof(FirstButtonText), typeof(string), typeof(YesNoCustomModal), string.Empty);

    /// <summary>
    /// The public static new readonly BindableProperty FirstButtonText property.
    /// </summary>
    public string FirstButtonText
    {
        get => (string)GetValue(FirstButtonTextProperty);
        set => SetValue(FirstButtonTextProperty, value);
    }

    /// <summary>
    /// The public static new readonly BindableProperty SecondButtonText property.
    /// </summary>
    public static readonly BindableProperty SecondButtonTextProperty =
        BindableProperty.Create(nameof(SecondButtonText), typeof(string), typeof(YesNoCustomModal), string.Empty);

    /// <summary>
    /// The public static new readonly BindableProperty SecondButtonText property.
    /// </summary>
    public string SecondButtonText
    {
        get => (string)GetValue(SecondButtonTextProperty);
        set => SetValue(SecondButtonTextProperty, value);
    }

    /// <summary>
    /// The public static new readonly BindableProperty FirstButtonType property.
    /// </summary>
    public static readonly BindableProperty FirstButtonTypeProperty =
        BindableProperty.Create(nameof(FirstButtonType), typeof(ModalButtonType), typeof(YesNoCustomModal), ModalButtonType.Secondary);

    /// <summary>
    /// The public static new readonly BindableProperty FirstButtonType property.
    /// </summary>
    public ModalButtonType FirstButtonType
    {
        get => (ModalButtonType)GetValue(FirstButtonTypeProperty);
        set => SetValue(FirstButtonTypeProperty, value);
    }

    /// <summary>
    /// The public static new readonly BindableProperty SecondButtonType property.
    /// </summary>
    public static readonly BindableProperty SecondButtonTypeProperty =
        BindableProperty.Create(nameof(SecondButtonType), typeof(ModalButtonType), typeof(YesNoCustomModal), ModalButtonType.Primary);

    /// <summary>
    /// The public static new readonly BindableProperty SecondButtonType property.
    /// </summary>
    public ModalButtonType SecondButtonType
    {
        get => (ModalButtonType)GetValue(SecondButtonTypeProperty);
        set => SetValue(SecondButtonTypeProperty, value);
    }
    #endregion

    #region Bindable Command Properties
    /// <summary>
    /// The SecondButtonCommand.
    /// </summary>
    public static readonly BindableProperty SecondButtonCommandProperty =
        BindableProperty.Create(nameof(SecondButtonCommandProperty), typeof(Command), typeof(YesNoCustomModal), null, BindingMode.TwoWay);

    /// <summary>
    /// Gets or sets the SecondButtonCommand.
    /// </summary>
    public Command SecondButtonCommand
    {
        get { return (Command)GetValue(SecondButtonCommandProperty); }
        set { SetValue(SecondButtonCommandProperty, value); }
    }
    #endregion

    #region Constructor
    /// <summary>
    /// Constructor of <see cref="YesNoCustomModal"/> class.
    /// </summary>
    public YesNoCustomModal()
    {
        InitializeComponent();
        firstButton.ButtonType = ModalButtonType.Secondary;
        secondButton.ButtonType = ModalButtonType.Primary;
    }
    #endregion

    #region Protected Methods
    /// <summary>
    /// On Property changed handled.
    /// </summary>
    protected override void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        base.OnPropertyChanged(propertyName);

        if (propertyName == nameof(FirstButtonType))
        {
            firstButton.ButtonType = FirstButtonType;
        }

        if (propertyName == nameof(SecondButtonType))
        {
            secondButton.ButtonType = SecondButtonType;
        }
    }
    #endregion

    #region Private Methods
    /// <summary>
    /// Close Modal.
    /// </summary>
    private async Task ClosePopup()
    {
        await MopupService.Instance.PopAsync();
    }

    /// <summary>
    /// Invoke Command.
    /// </summary>
    private async Task InvokeSecondCommandPopup()
    {
        await MopupService.Instance.PopAsync();
        SecondButtonCommand?.Execute(null);
    }
    #endregion
}