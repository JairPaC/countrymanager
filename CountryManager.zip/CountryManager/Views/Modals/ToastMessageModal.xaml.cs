﻿using CountryManager.Helper;
using CountryManager.Helper.Enums;
using Mopups.Pages;
using Mopups.Services;

namespace CountryManager.Views.Modals;

public partial class ToastMessageModal : PopupPage
{
    #region Constructor
    /// <summary>
    /// Constructor of <see cref="ToastMessageModal"/> class.
    /// </summary>
    public ToastMessageModal(string message, ToastType toastType, string title)
    {
        InitializeComponent();
        CloseWhenBackgroundIsClicked = true;
        lblMessage.Text = message;
        lblTitle.IsVisible = !string.IsNullOrEmpty(title);
        lblTitle.Text = title;

        if (toastType == ToastType.Success)
        {
            imgToast.Source = new FontImageSource
            {
                Glyph = FAIcons.CircleCheck,
                FontFamily = "FAIcons"
            };

            frmControl.BackgroundColor = (Color)App.ResourceDictionary["Colors"]["Success"];
        }
        else
        {
            imgToast.Source = new FontImageSource
            {
                Glyph = FAIcons.CircleExclamation,
                FontFamily = "FAIcons"
            };

            frmControl.BackgroundColor = (Color)App.ResourceDictionary["Colors"]["Red"];
        }
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// Show Toast.
    /// </summary>
    public static async Task Show(string message, ToastType toastType = ToastType.Success, int millisecondsDuration = 2000, string title = "")
    {
        var popPage = new ToastMessageModal(message, toastType, title);
        await MopupService.Instance.PushAsync(popPage);

        _ = Task.Delay(millisecondsDuration)
            .ContinueWith(async _ => await MopupService.Instance.RemovePageAsync(popPage));
    }
    #endregion
}
