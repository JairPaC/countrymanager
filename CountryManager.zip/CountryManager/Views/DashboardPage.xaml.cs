﻿using CountryManager.Services.Implementation;
using CountryManager.ViewModels;

namespace CountryManager.Views;

public partial class DashboardPage : ContentPage
{
	#region Constructor
	/// <summary>
	/// Constructor of <see cref="DashboardPage"/> class.
	/// </summary>
	public DashboardPage()
	{
		InitializeComponent();
        BindingContext = AppContainer.Instance.Resolve(typeof(DashboardViewModal));
    }
    #endregion
}
