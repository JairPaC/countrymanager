﻿using System.Windows.Input;
using CountryManager.Controls.Enums;

namespace CountryManager.Controls.Base
{
    public class CustomEntryBase : Entry
    {
        #region Bindable Properties
        /// <summary>
        /// Border Color Property.
        /// </summary>
        public static readonly BindableProperty BorderColorProperty =
            BindableProperty.Create(nameof(BorderColor), typeof(Color), typeof(CustomEntryBase), Colors.White);

        /// <summary>
        /// Gets or sets Border Color value.
        /// </summary>
        public Color BorderColor
        {
            get { return (Color)GetValue(BorderColorProperty); }
            set { SetValue(BorderColorProperty, value); }
        }

        /// <summary>
        /// Border Width Property.
        /// </summary>
        public static readonly BindableProperty BorderWidthProperty =
            BindableProperty.Create(nameof(BorderWidth), typeof(int), typeof(CustomEntryBase), DeviceInfo.Platform == DevicePlatform.iOS ? 1 : 2);

        /// <summary>
        /// Gets or sets Border Width value.
        /// </summary>
        public int BorderWidth
        {
            get { return (int)GetValue(BorderWidthProperty); }
            set { SetValue(BorderWidthProperty, value); }
        }

        /// <summary>
        /// Corner Radius Property.
        /// </summary>
        public static readonly BindableProperty CornerRadiusProperty =
            BindableProperty.Create(nameof(CornerRadius), typeof(double), typeof(CustomEntryBase), DeviceInfo.Platform == DevicePlatform.iOS ? 6d : 7d);

        /// <summary>
        /// Gets or sets Corner Radius value.
        /// </summary>
        public double CornerRadius
        {
            get { return (double)GetValue(CornerRadiusProperty); }
            set { SetValue(CornerRadiusProperty, value); }
        }

        /// <summary>
        /// Is Curved Corners Enabled Property.
        /// </summary>
        public static readonly BindableProperty IsCurvedCornersEnabledProperty =
            BindableProperty.Create(nameof(IsCurvedCornersEnabled), typeof(bool), typeof(CustomEntryBase), false);

        /// <summary>
        /// Gets or sets IsCurvedCornersEnabled value
        /// </summary>
        public bool IsCurvedCornersEnabled
        {
            get { return (bool)GetValue(IsCurvedCornersEnabledProperty); }
            set { SetValue(IsCurvedCornersEnabledProperty, value); }
        }

        /// <summary>
        /// The next view property.
        /// </summary>
        public static readonly BindableProperty NextViewProperty =
            BindableProperty.Create(nameof(NextView), typeof(CustomEntry), typeof(CustomEntryBase));

        /// <summary>
        /// Gets or sets the next view.
        /// </summary>
        /// <value>The next view.</value>
        public CustomEntry NextView
        {
            get { return (CustomEntry)GetValue(NextViewProperty); }
            set { SetValue(NextViewProperty, value); }
        }

        /// <summary>
        /// The previous view property.
        /// </summary>
        public static readonly BindableProperty PrevViewProperty =
            BindableProperty.Create(nameof(PrevView), typeof(CustomEntry), typeof(CustomEntryBase));

        /// <summary>
        /// Gets or sets the previous view.
        /// </summary>
        /// <value>The previous view.</value>
        public CustomEntry PrevView
        {
            get { return (CustomEntry)GetValue(PrevViewProperty); }
            set { SetValue(PrevViewProperty, value); }
        }

        /// <summary>
        /// The return type property.
        /// </summary>
        public static readonly new BindableProperty ReturnTypeProperty =
            BindableProperty.Create(nameof(ReturnType), typeof(ReturnTypeKeyboard), typeof(CustomEntryBase), ReturnTypeKeyboard.Done);

        /// <summary>
        /// Gets or sets the type of the return.
        /// </summary>
        /// <value>The type of the return.</value>
        public new ReturnTypeKeyboard ReturnType
        {
            get { return (ReturnTypeKeyboard)GetValue(ReturnTypeProperty); }
            set { SetValue(ReturnTypeProperty, value); }
        }

        /// <summary>
        /// The should invoke action property.
        /// </summary>
        public static readonly BindableProperty ShouldInvokeCompleteProperty =
            BindableProperty.Create(nameof(ShouldInvokeComplete), typeof(bool), typeof(CustomEntryBase), false);

        /// <summary>
        /// Gets or sets a value indicating whether this  should
        /// invoke action.
        /// </summary>
        /// <value><c>true</c> if should invoke action; otherwise, <c>false</c>.</value>
        public bool ShouldInvokeComplete
        {
            get { return (bool)GetValue(ShouldInvokeCompleteProperty); }
            set { SetValue(ShouldInvokeCompleteProperty, value); }
        }

        /// <summary>
        /// The keyboard type property.
        /// </summary>
        public static readonly BindableProperty KeyboardTypeProperty =
            BindableProperty.Create(nameof(KeyboardType), typeof(EntryKeyboardType), typeof(CustomEntryBase), EntryKeyboardType.Text);

        /// <summary>
        /// Gets or sets the type of the keyboard.
        /// </summary>
        /// <value>The type of the keyboard.</value>
        public EntryKeyboardType KeyboardType
        {
            get { return (EntryKeyboardType)GetValue(KeyboardTypeProperty); }
            set { SetValue(KeyboardTypeProperty, value); }
        }

        /// <summary>
        /// The formatted value property.
        /// </summary>
        public static readonly BindableProperty FormattedValueProperty =
            BindableProperty.Create(nameof(FormattedValue), typeof(string), typeof(CustomEntryBase), string.Empty, BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the formatted value.
        /// </summary>
        /// <value>The formatted value.</value>
        public string FormattedValue
        {
            get { return (string)GetValue(FormattedValueProperty); }
            set { SetValue(FormattedValueProperty, value); }
        }

        /// <summary>
        /// The value to send property.
        /// </summary>
        public static readonly BindableProperty ValueToSendProperty =
            BindableProperty.Create(nameof(ValueToSend), typeof(string), typeof(CustomEntryBase), default(string), BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the value to send.
        /// </summary>
        /// <value>The value to send.</value>
        public string ValueToSend
        {
            get { return (string)GetValue(ValueToSendProperty); }
            set { SetValue(ValueToSendProperty, value); }
        }

        /// <summary>
        /// The on complete command property.
        /// </summary>
        public static readonly BindableProperty OnCompleteCommandProperty =
            BindableProperty.Create(nameof(OnCompleteCommand), typeof(ICommand), typeof(CustomEntryBase), null, BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the on complete command.
        /// </summary>
        /// <value>The on complete command.</value>
        public ICommand OnCompleteCommand
        {
            get { return (ICommand)GetValue(OnCompleteCommandProperty); }
            set { SetValue(OnCompleteCommandProperty, value); }
        }
        #endregion

        #region Public Mehthods
        /// <summary>
        /// Invokes the completed.
        /// </summary>
        public void InvokeCompleted()
        {
            if (Completed != null)
            {
                Completed.Invoke(this, null);
            }
        }

        /// <summary>
        /// Ons the next.
        /// </summary>
        public void OnNext()
        {
            NextView?.CustomEntryBase?.Focus();
        }

        /// <summary>
        /// Ons the previous.
        /// </summary>
        public void OnPrev()
        {
            PrevView?.CustomEntryBase?.Focus();
        }

        /// <summary>
        /// Occurs when completed.
        /// </summary>
        public new event EventHandler Completed;

        /// <summary>
        /// Sends the complete.
        /// </summary>
        public void SendComplete()
        {
            if (ReturnType != ReturnTypeKeyboard.Next)
            {
                Unfocus();
            }
            else
            {
                OnNext();
            }

            if (ShouldInvokeComplete)
            {
                OnCompleteCommand?.Execute(this);
                // Call all the methods attached to custom_entry event handler Completed
                InvokeCompleted();
            }
            else
            {
                Unfocus();
            }
        }
        #endregion
    }
}