﻿using System.Runtime.CompilerServices;
using System.Windows.Input;
using System.Xml;
using CountryManager.Controls.Enums;

namespace CountryManager.Controls;

public partial class GeneralButton : Frame
{
    #region Bindable Properties
    /// <summary>
    /// The ShowLeftImage property.
    /// </summary>
    public static readonly BindableProperty ShowLeftImageProperty =
        BindableProperty.Create(nameof(ShowLeftImage), typeof(bool), typeof(GeneralButton), false);

    /// <summary>
    /// Gets or sets the ShowLeftImage.
    /// </summary>
    /// <value>The ShowLeftImage.</value>
    public bool ShowLeftImage
    {
        get { return (bool)GetValue(ShowLeftImageProperty); }
        set { SetValue(ShowLeftImageProperty, value); }
    }

    /// <summary>
    /// The ShowRightImage property.
    /// </summary>
    public static readonly BindableProperty ShowRightImageProperty =
        BindableProperty.Create(nameof(ShowRightImage), typeof(bool), typeof(GeneralButton), false);

    /// <summary>
    /// Gets or sets the ShowRightImage.
    /// </summary>
    /// <value>The ShowRightImage.</value>
    public bool ShowRightImage
    {
        get { return (bool)GetValue(ShowRightImageProperty); }
        set { SetValue(ShowRightImageProperty, value); }
    }

    /// <summary>
    /// The LeftImage property.
    /// </summary>
    public static readonly BindableProperty LeftImageProperty =
        BindableProperty.Create(nameof(LeftImage), typeof(string), typeof(GeneralButton), string.Empty);

    /// <summary>
    /// Gets or sets the LeftImage.
    /// </summary>
    /// <value>The LeftImage.</value>
    public string LeftImage
    {
        get { return (string)GetValue(LeftImageProperty); }
        set { SetValue(LeftImageProperty, value); }
    }

    /// <summary>
    /// The RightImage property.
    /// </summary>
    public static readonly BindableProperty RightImageProperty =
        BindableProperty.Create(nameof(RightImage), typeof(string), typeof(GeneralButton), string.Empty);

    /// <summary>
    /// Gets or sets the RightImage.
    /// </summary>
    /// <value>The RightImage.</value>
    public string RightImage
    {
        get { return (string)GetValue(RightImageProperty); }
        set { SetValue(RightImageProperty, value); }
    }

    /// <summary>
    /// The LeftImageSize property.
    /// </summary>
    public static readonly BindableProperty LeftImageSizeProperty =
        BindableProperty.Create(nameof(LeftImageSize), typeof(double), typeof(GeneralButton), 15d);

    /// <summary>
    /// Gets or sets the LeftImageSize.
    /// </summary>
    /// <value>The LeftImageSize.</value>
    public double LeftImageSize
    {
        get { return (double)GetValue(LeftImageSizeProperty); }
        set { SetValue(LeftImageSizeProperty, value); }
    }

    /// <summary>
    /// The RightImageSize property.
    /// </summary>
    public static readonly BindableProperty RightImageSizeProperty =
        BindableProperty.Create(nameof(RightImageSize), typeof(double), typeof(GeneralButton), 15d);

    /// <summary>
    /// Gets or sets the RightImageSize.
    /// </summary>
    /// <value>The RightImageSize.</value>
    public double RightImageSize
    {
        get { return (double)GetValue(RightImageSizeProperty); }
        set { SetValue(RightImageSizeProperty, value); }
    }

    /// <summary>
    /// The TextButton property.
    /// </summary>
    public static readonly BindableProperty TextButtonProperty =
        BindableProperty.Create(nameof(TextButton), typeof(string), typeof(GeneralButton), string.Empty);

    /// <summary>
    /// Gets or sets the TextButton.
    /// </summary>
    /// <value>The TextButton.</value>
    public string TextButton
    {
        get { return (string)GetValue(TextButtonProperty); }
        set { SetValue(TextButtonProperty, value); }
    }

    /// <summary>
    /// The ButtonType property.
    /// </summary>
    public static readonly BindableProperty ButtonTypeProperty =
        BindableProperty.Create(nameof(ButtonType), typeof(ModalButtonType), typeof(GeneralButton), ModalButtonType.Primary);

    /// <summary>
    /// Gets or sets the ButtonType.
    /// </summary>
    /// <value>The ButtonType.</value>
    public ModalButtonType ButtonType
    {
        get { return (ModalButtonType)GetValue(ButtonTypeProperty); }
        set { SetValue(ButtonTypeProperty, value); }
    }

    /// <summary>
    /// The on OnTapCommand property.
    /// </summary>
    public static readonly BindableProperty OnTapCommandProperty =
        BindableProperty.Create(nameof(OnTapCommand), typeof(ICommand), typeof(GeneralButton), null, BindingMode.TwoWay);

    /// <summary>
    /// Gets or sets the OnTapCommand.
    /// </summary>
    /// <value>The OnTapCommand.</value>
    public ICommand OnTapCommand
    {
        get { return (ICommand)GetValue(OnTapCommandProperty); }
        set { SetValue(OnTapCommandProperty, value); }
    }

    /// <summary>
    /// The Selected Item Changed Command Bindable Property.
    /// </summary>
    public static readonly BindableProperty OnTapCommandParameterProperty =
        BindableProperty.Create(nameof(OnTapCommandParameter), typeof(object), typeof(GeneralButton), null, BindingMode.TwoWay);

    /// <summary>
    /// Gets or sets the Selected Item ChangedCommand Property.
    /// </summary>
    public object OnTapCommandParameter
    {
        get { return GetValue(OnTapCommandParameterProperty); }
        set { SetValue(OnTapCommandParameterProperty, value); }
    }
    #endregion

    #region Constructor
    /// <summary>
    /// Constructor of <see cref="GeneralButton"/> class.
    /// </summary>
    public GeneralButton()
    {
        InitializeComponent();

        // Primary Default
        parentControl.BorderColor = (Color)App.ResourceDictionary["Colors"]["Primary"];
        parentControl.BackgroundColor = (Color)App.ResourceDictionary["Colors"]["Primary"];
        lblText.TextColor = (Color)App.ResourceDictionary["Colors"]["White"];
    }
    #endregion

    #region Protected Methods
    /// <summary>
    /// On Property changed handled.
    /// </summary>
    protected override void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        base.OnPropertyChanged(propertyName);

        if (propertyName == nameof(ButtonType))
        {
            switch (ButtonType)
            {
                case ModalButtonType.Primary:
                    parentControl.BorderColor = (Color)App.ResourceDictionary["Colors"]["Primary"];
                    parentControl.BackgroundColor = (Color)App.ResourceDictionary["Colors"]["Primary"];
                    lblText.TextColor = (Color)App.ResourceDictionary["Colors"]["White"];
                    ChangeImageColor((Color)App.ResourceDictionary["Colors"]["White"]);
                    break;
                case ModalButtonType.Secondary:
                    parentControl.BorderColor = (Color)App.ResourceDictionary["Colors"]["Primary"];
                    parentControl.BackgroundColor = (Color)App.ResourceDictionary["Colors"]["White"];
                    lblText.TextColor = (Color)App.ResourceDictionary["Colors"]["Primary"];
                    ChangeImageColor((Color)App.ResourceDictionary["Colors"]["Primary"]);
                    break;
            }
        }

        if (propertyName == nameof(LeftImage))
        {
            imgLeft.Source = new FontImageSource
            {
                FontFamily = "FAIcons",
                Glyph = LeftImage,
                Size = LeftImageSize,
                Color = (Color)App.ResourceDictionary["Colors"]["White"]
            };
        }

        if (propertyName == nameof(RightImage))
        {
            imgRight.Source = new FontImageSource
            {
                FontFamily = "FAIcons",
                Glyph = RightImage,
                Size = RightImageSize,
                Color = (Color)App.ResourceDictionary["Colors"]["White"]
            };
        }

        if (propertyName == nameof(ShowLeftImage))
        {
            imgLeft.IsVisible = ShowLeftImage;
        }
    }
    #endregion

    #region Private Methods
    /// <summary>
    /// Change image color when type changed.
    /// </summary>
    public void ChangeImageColor(Color imageColor)
    {
        imgLeft.Source = new FontImageSource
        {
            FontFamily = "FAIcons",
            Glyph = LeftImage,
            Size = LeftImageSize,
            Color = imageColor
        };

        imgRight.Source = new FontImageSource
        {
            FontFamily = "FAIcons",
            Glyph = RightImage,
            Size = RightImageSize,
            Color = imageColor
        };
    }
    #endregion
}
