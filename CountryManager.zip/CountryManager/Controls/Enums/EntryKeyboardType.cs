﻿namespace CountryManager.Controls.Enums
{
    public enum EntryKeyboardType
	{
        Text,
        Numeric,
        Decimal,
        Email,
        Telephone
    }
}

