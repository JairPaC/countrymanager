﻿namespace CountryManager.Controls.Enums
{
    public enum ReturnTypeKeyboard
	{
        Default,
        Done,
        Go,
        Next,
        Search,
        Send,
        SignIn
    }
}

