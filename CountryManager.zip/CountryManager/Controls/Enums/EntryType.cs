﻿namespace CountryManager.Controls.Enums
{
    public enum EntryType
	{
        Text,
        Number,
        Decimal,
        Password,
        Search,
        Email,
        Numeric,
        Percentage,
        Phone
    }
}

