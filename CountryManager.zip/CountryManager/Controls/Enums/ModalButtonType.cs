﻿namespace CountryManager.Controls.Enums
{
    public enum ModalButtonType
	{
        Primary,
        Secondary,
    }
}

