﻿namespace CountryManager.Controls.Behaviors
{
    public class LengthValidateBehavior : Behavior<Entry>
    {
        #region Binding Properties
        public static BindableProperty MaxLengthProperty = BindableProperty.Create(nameof(MaxLength), typeof(int), typeof(LengthValidateBehavior), 10);

        public int MaxLength
        {
            get { return (int)GetValue(MaxLengthProperty); }
            set { SetValue(MaxLengthProperty, value); }
        }

        public static BindableProperty MaxDecimalProperty = BindableProperty.Create(nameof(MaxDecimal), typeof(int), typeof(LengthValidateBehavior), 0);

        public int MaxDecimal
        {
            get { return (int)GetValue(MaxDecimalProperty); }
            set { SetValue(MaxDecimalProperty, value); }
        }
        #endregion

        #region Public Methods
        protected override void OnAttachedTo(Entry entry)
        {
            entry.TextChanged += OnEntryTextChanged;
            entry.Unfocused += OnEntryUnfocused;
            base.OnAttachedTo(entry);
        }

        protected override void OnDetachingFrom(Entry entry)
        {
            entry.TextChanged -= OnEntryTextChanged;
            entry.Unfocused -= OnEntryUnfocused;
            base.OnDetachingFrom(entry);
        }

        /// <summary>
        /// Handle entry text change and validate length and decimals.
        /// </summary>
        void OnEntryTextChanged(object? sender, TextChangedEventArgs args)
        {
            if (sender is Entry entry)
            {
                if (string.IsNullOrEmpty(args.NewTextValue))
                {
                    return;
                }

                if (MaxDecimal > 0 && args.NewTextValue.Contains("."))
                {
                    if (args.NewTextValue.Length - 1 - args.NewTextValue.IndexOf(".") > MaxDecimal)
                    {
                        var s = args.NewTextValue.Substring(0, args.NewTextValue.IndexOf(".") + MaxDecimal + 1);
                        entry.Text = s;
                        entry.SelectionLength = s.Length;
                    }

                    if (args.NewTextValue.Substring(0, args.NewTextValue.IndexOf(".")).Length > MaxLength)
                    {
                        entry.Text = args.OldTextValue;
                    }
                }
                else if (args.NewTextValue.Length > MaxLength)
                {
                    entry.Text = args.OldTextValue;
                }
            }
        }

        /// <summary>
        /// Handle unfocused to remove the last period if the user added it.
        /// </summary>
        void OnEntryUnfocused(object? sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;

            if (!string.IsNullOrEmpty(entry.Text) && entry.Text.EndsWith("."))
            {
                entry.Text = entry.Text.Replace(".", "");
            }
        }
        #endregion
    }
}