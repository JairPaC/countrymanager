﻿using System;
using System.Text.RegularExpressions;
using CountryManager.Controls.Base;

namespace CountryManager.Controls.Behaviors
{
	public class EntryCustomFormatBehavior : Behavior<Entry>
    {
        #region Private Properties
        private const string _customFormat = "(###) ###-####";
        private const string _customPlaceHolder = "(###) ###-####";
        private List<string> _separator = new List<string>
                    {
                        "(",
                        ")",
                        "-"
                    };
        #endregion

        #region Public Properties
        /// <summary>
        /// The text property.
        /// </summary>
        public static readonly BindableProperty TextProperty =
            BindableProperty.Create(nameof(Text), typeof(string), typeof(EntryCustomFormatBehavior), string.Empty, BindingMode.OneWayToSource);

        /// <summary>
        /// Gets or sets the text.
        /// </summary>
        /// <value>The text.</value>
        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        /// <summary>
        /// The formatted value property.
        /// </summary>
        public static readonly BindableProperty FormattedValueProperty =
            BindableProperty.Create(nameof(FormattedValue), typeof(string), typeof(EntryCustomFormatBehavior), default(string), BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the formatted value.
        /// </summary>
        /// <value>The formatted value.</value>
        public string FormattedValue
        {
            get { return (string)GetValue(FormattedValueProperty); }
            set { SetValue(FormattedValueProperty, value); }
        }

        /// <summary>
        /// The value to send property.
        /// </summary>
        public static readonly BindableProperty ValueToSendProperty =
            BindableProperty.Create(nameof(ValueToSend), typeof(string), typeof(EntryCustomFormatBehavior), default(string), BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the value to send.
        /// </summary>
        /// <value>The value to send.</value>
        public string ValueToSend
        {
            get { return (string)GetValue(ValueToSendProperty); }
            set { SetValue(ValueToSendProperty, value); }
        }
        #endregion

        #region Private Properties
        private string _formattedValue;
        private EntryCustomMaskBehavior MaskBehavior;
        #endregion

        #region Public Methods
        /// <summary>
        /// Initializes a new instance of the class.
        /// </summary>
        public EntryCustomFormatBehavior()
        {
            _formattedValue = string.Empty;
            MaskBehavior = new EntryCustomMaskBehavior();
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Ons the attached to.
        /// </summary>
        /// <param name="bindable">Bindable.</param>
        protected override void OnAttachedTo(Entry bindable)
        {
            if (bindable != null)
            {
                bindable.Placeholder = _customPlaceHolder;
                bindable.TextChanged += Bindable_TextChanged;
                base.OnAttachedTo(bindable);
            }
        }

        /// <summary>
        /// Ons the detaching from.
        /// </summary>
        /// <param name="bindable">Bindable.</param>
        protected override void OnDetachingFrom(Entry bindable)
        {
            if (bindable != null)
            {
                bindable.TextChanged -= Bindable_TextChanged;
                OnDetachingFrom(bindable);
            }
        }

        /// <summary>
        /// Bindables the text changed.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="args">Arguments.</param>
        private void Bindable_TextChanged(object sender, TextChangedEventArgs args)
        {
            try
            {
                if ((args.NewTextValue == args.OldTextValue) ||
                   string.IsNullOrEmpty(args.NewTextValue))
                {
                    _formattedValue = string.Empty;

                    ((CustomEntryBase)sender).ValueToSend = string.Empty;
                    ((CustomEntryBase)sender).FormattedValue = string.Empty;
                    return;
                }

                if (args.NewTextValue.Length > _customFormat.Length)
                {
                    ((Entry)sender).Text = args.OldTextValue;
                    return;
                }

                string newValue = string.Empty;
                string oldValue = string.Empty;

                foreach (var sep in _separator)
                {
                    newValue = args.NewTextValue.Replace(sep, string.Empty);
                    oldValue = args.OldTextValue == null ? string.Empty : args.OldTextValue.Replace(sep, string.Empty);
                }

                if (newValue.Length != oldValue.Length)
                {
                    _formattedValue = MaskBehavior.ProcessMask(((Entry)sender).Text, args.OldTextValue ?? string.Empty, args.NewTextValue, _customFormat);
                    ((CustomEntryBase)sender).FormattedValue = _formattedValue;
                    ((Entry)sender).Text = _formattedValue;
                    ValueToSend = Regex.Replace(_formattedValue, "[^0-9]", string.Empty);
                }
            }
            catch (Exception ex)
            {

            }
        }
        #endregion
    }
}