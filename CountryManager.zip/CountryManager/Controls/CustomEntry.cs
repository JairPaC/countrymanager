﻿using System.Runtime.CompilerServices;
using System.Windows.Input;
using CountryManager.Controls.Base;
using CountryManager.Controls.Behaviors;
using CountryManager.Controls.Enums;
using CountryManager.Helper;

namespace CountryManager.Controls
{
	public class CustomEntry : Frame
    {
        #region Private Properties
        StackLayout _containerStack;
        Label _rightTextLbl;
        Image _rightImagePassword;
        bool _showedPassword;
        #endregion

        #region Public Properties
        public CustomEntryBase CustomEntryBase;
        #endregion

        #region Bindable Properties
        /// <summary>
        /// The text property.
        /// </summary>
        public static readonly BindableProperty TextProperty =
            BindableProperty.Create(nameof(Text), typeof(string), typeof(CustomEntry), string.Empty, BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the text.
        /// </summary>
        /// <value>The text.</value>
        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        /// <summary>
        /// The IsPassword property.
        /// </summary>
        public static readonly BindableProperty IsPasswordProperty =
            BindableProperty.Create(nameof(IsPassword), typeof(bool), typeof(CustomEntry), false, BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the IsPassword.
        /// </summary>
        /// <value>The IsPassword.</value>
        public bool IsPassword
        {
            get { return (bool)GetValue(IsPasswordProperty); }
            set { SetValue(IsPasswordProperty, value); }
        }

        /// <summary>
        /// Placeholder Property.
        /// </summary>
        public static readonly BindableProperty PlaceholderProperty =
            BindableProperty.Create(nameof(Placeholder), typeof(string), typeof(CustomEntry), string.Empty);

        /// <summary>
        /// Gets or sets Placeholder value.
        /// </summary>
        public string Placeholder
        {
            get { return (string)GetValue(PlaceholderProperty); }
            set { SetValue(PlaceholderProperty, value); }
        }

        /// <summary>
        /// KeyboardType Property.
        /// </summary>
        public static readonly BindableProperty KeyboardTypeProperty =
            BindableProperty.Create(nameof(KeyboardType), typeof(Keyboard), typeof(CustomEntry), Keyboard.Text);

        /// <summary>
        /// Gets or sets KeyboardType value.
        /// </summary>
        public Keyboard KeyboardType
        {
            get { return (Keyboard)GetValue(KeyboardTypeProperty); }
            set { SetValue(KeyboardTypeProperty, value); }
        }

        /// <summary>
        /// ShowRightText Property.
        /// </summary>
        public static readonly BindableProperty ShowRightTextProperty =
            BindableProperty.Create(nameof(ShowRightText), typeof(bool), typeof(CustomEntry), false);

        /// <summary>
        /// Gets or sets ShowRightText value.
        /// </summary>
        public bool ShowRightText
        {
            get { return (bool)GetValue(ShowRightTextProperty); }
            set { SetValue(ShowRightTextProperty, value); }
        }

        /// <summary>
        /// EnableShowPassword Property.
        /// </summary>
        public static readonly BindableProperty EnableShowPasswordProperty =
            BindableProperty.Create(nameof(EnableShowPassword), typeof(bool), typeof(CustomEntry), false);

        /// <summary>
        /// Gets or sets EnableShowPassword value.
        /// </summary>
        public bool EnableShowPassword
        {
            get { return (bool)GetValue(EnableShowPasswordProperty); }
            set { SetValue(EnableShowPasswordProperty, value); }
        }

        /// <summary>
        /// RightText Property.
        /// </summary>
        public static readonly BindableProperty RightTextProperty =
            BindableProperty.Create(nameof(RightText), typeof(string), typeof(CustomEntry), string.Empty);

        /// <summary>
        /// Gets or sets RightText value.
        /// </summary>
        public string RightText
        {
            get { return (string)GetValue(RightTextProperty); }
            set { SetValue(RightTextProperty, value); }
        }

        /// <summary>
        /// Is Curved Corners Enabled Property.
        /// </summary>
        public static readonly BindableProperty IsCurvedCornersEnabledProperty =
            BindableProperty.Create(nameof(IsCurvedCornersEnabled), typeof(bool), typeof(CustomEntry), false);

        /// <summary>
        /// Gets or sets IsCurvedCornersEnabled value.
        /// </summary>
        public bool IsCurvedCornersEnabled
        {
            get { return (bool)GetValue(IsCurvedCornersEnabledProperty); }
            set { SetValue(IsCurvedCornersEnabledProperty, value); }
        }

        /// <summary>
        /// MaxLength Property.
        /// </summary>
        public static readonly BindableProperty MaxLengthProperty =
            BindableProperty.Create(nameof(MaxLength), typeof(int), typeof(CustomEntry), 10);

        /// <summary>
        /// Gets or sets MaxLength value.
        /// </summary>
        public int MaxLength
        {
            get { return (int)GetValue(MaxLengthProperty); }
            set { SetValue(MaxLengthProperty, value); }
        }

        /// <summary>
        /// DecimalLength Property.
        /// </summary>
        public static readonly BindableProperty DecimalLengthProperty =
            BindableProperty.Create(nameof(DecimalLength), typeof(int), typeof(CustomEntry), 0);

        /// <summary>
        /// Gets or sets DecimalLength value.
        /// </summary>
        public int DecimalLength
        {
            get { return (int)GetValue(DecimalLengthProperty); }
            set { SetValue(DecimalLengthProperty, value); }
        }

        /// <summary>
        /// TypeEntry Property.
        /// </summary>
        public static readonly BindableProperty TypeEntryProperty =
            BindableProperty.Create(nameof(TypeEntry), typeof(EntryType), typeof(CustomEntry), EntryType.Text);

        /// <summary>
        /// Gets or sets TypeEntry value.
        /// </summary>
        public EntryType TypeEntry
        {
            get { return (EntryType)GetValue(TypeEntryProperty); }
            set { SetValue(TypeEntryProperty, value); }
        }

        /// <summary>
        /// The formatted value property.
        /// </summary>
        public static readonly BindableProperty FormattedValueProperty =
            BindableProperty.Create(nameof(FormattedValue), typeof(string), typeof(CustomEntry), string.Empty, BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the formatted value.
        /// </summary>
        /// <value>The formatted value.</value>
        public string FormattedValue
        {
            get { return (string)GetValue(FormattedValueProperty); }
            set { SetValue(FormattedValueProperty, value); }
        }

        /// <summary>
        /// The value to send property.
        /// </summary>
        public static readonly BindableProperty ValueToSendProperty =
            BindableProperty.Create(nameof(ValueToSend), typeof(string), typeof(CustomEntry), default(string), BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the value to send.
        /// </summary>
        /// <value>The value to send.</value>
        public string ValueToSend
        {
            get { return (string)GetValue(ValueToSendProperty); }
            set { SetValue(ValueToSendProperty, value); }
        }
        #endregion

        #region Tab Bindable Properties
        /// <summary>
        /// The next view property.
        /// </summary>
        public static readonly BindableProperty NextViewProperty =
            BindableProperty.Create(nameof(NextView), typeof(CustomEntry), typeof(CustomEntry));

        /// <summary>
        /// Gets or sets the next view.
        /// </summary>
        /// <value>The next view.</value>
        public CustomEntry NextView
        {
            get { return (CustomEntry)GetValue(NextViewProperty); }
            set { SetValue(NextViewProperty, value); }
        }

        /// <summary>
        /// The previous view property.
        /// </summary>
        public static readonly BindableProperty PrevViewProperty =
            BindableProperty.Create(nameof(PrevView), typeof(CustomEntry), typeof(CustomEntry));

        /// <summary>
        /// Gets or sets the previous view.
        /// </summary>
        /// <value>The previous view.</value>
        public CustomEntry PrevView
        {
            get { return (CustomEntry)GetValue(PrevViewProperty); }
            set { SetValue(PrevViewProperty, value); }
        }

        /// <summary>
        /// The return type property.
        /// </summary>
        public static readonly BindableProperty ReturnTypeProperty =
            BindableProperty.Create(nameof(ReturnType), typeof(ReturnTypeKeyboard), typeof(CustomEntry), ReturnTypeKeyboard.Done);

        /// <summary>
        /// Gets or sets the type of the return.
        /// </summary>
        /// <value>The type of the return.</value>
        public ReturnTypeKeyboard ReturnType
        {
            get { return (ReturnTypeKeyboard)GetValue(ReturnTypeProperty); }
            set { SetValue(ReturnTypeProperty, value); }
        }

        /// <summary>
        /// The should invoke action property.
        /// </summary>
        public static readonly BindableProperty ShouldInvokeCompleteProperty =
            BindableProperty.Create(nameof(ShouldInvokeComplete), typeof(bool), typeof(CustomEntry), false);

        /// <summary>
        /// Gets or sets a value indicating whether this should invoke action.
        /// </summary>
        /// <value><c>true</c> if should invoke action; otherwise, <c>false</c>.</value>
        public bool ShouldInvokeComplete
        {
            get { return (bool)GetValue(ShouldInvokeCompleteProperty); }
            set { SetValue(ShouldInvokeCompleteProperty, value); }
        }

        /// <summary>
        /// The on complete command property.
        /// </summary>
        public static readonly BindableProperty OnCompleteCommandProperty =
            BindableProperty.Create(nameof(OnCompleteCommand), typeof(ICommand), typeof(CustomEntry), null, BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the on complete command.
        /// </summary>
        /// <value>The on complete command.</value>
        public ICommand OnCompleteCommand
        {
            get { return (ICommand)GetValue(OnCompleteCommandProperty); }
            set { SetValue(OnCompleteCommandProperty, value); }
        }
        #endregion

        #region Bindable Command Properties
        /// <summary>
        /// The text changed command property.
        /// </summary>
        public static readonly BindableProperty TextChangedCommandProperty =
            BindableProperty.Create(nameof(TextChangedCommand), typeof(Command), typeof(CustomEntry), null, BindingMode.TwoWay);

        /// <summary>
        /// Gets or sets the text changed command.
        /// </summary>
        /// <value>The text changed command.</value>
        public Command TextChangedCommand
        {
            get { return (Command)GetValue(TextChangedCommandProperty); }
            set { SetValue(TextChangedCommandProperty, value); }
        }
        #endregion

        #region
        /// <summary>
        /// Constructor of <see cref="CustomEntry"/> class.
        /// </summary>
        public CustomEntry()
        {
            BorderColor = (Color)App.ResourceDictionary["Colors"]["Gray400"];
            HasShadow = false;
            HeightRequest = 50;
            Padding = 0;
            CornerRadius = 10;
            _containerStack = new StackLayout();
            _containerStack.Orientation = StackOrientation.Horizontal;

            CustomEntryBase = new CustomEntryBase();
            CustomEntryBase.BindingContext = this;
            CustomEntryBase.TextColor = Colors.Black;
            CustomEntryBase.HeightRequest = 50;
            CustomEntryBase.FontSize = 17;
            CustomEntryBase.HorizontalOptions = LayoutOptions.FillAndExpand;
            CustomEntryBase.HorizontalTextAlignment = TextAlignment.Start;
            CustomEntryBase.IsCurvedCornersEnabled = IsCurvedCornersEnabled;
            CustomEntryBase.Keyboard = KeyboardType;
            CustomEntryBase.TextChanged += CustomEntryBase_TextChanged;
            CustomEntryBase.Focused += CustomEditor_Focused;
            CustomEntryBase.SetBinding(Entry.TextProperty, nameof(Text), BindingMode.TwoWay);

            _rightTextLbl = new Label();
            _rightTextLbl.FontSize = 17;
            _rightTextLbl.Margin = new Thickness(0, 0, 10, 0);
            _rightTextLbl.TextColor = Colors.Gray;
            _rightTextLbl.HorizontalOptions = LayoutOptions.End;
            _rightTextLbl.VerticalOptions = LayoutOptions.CenterAndExpand;

            TapGestureRecognizer onImageTapped = new TapGestureRecognizer
            {
                Command = new Command((o) =>
                {
                    _showedPassword = !_showedPassword;

                    if (IsPassword)
                    {
                        CustomEntryBase.IsPassword = !_showedPassword;
                    }
                    HandlePasswordVisibility();
                })
            };

            _rightImagePassword = new Image();
            _showedPassword = false;
            HandlePasswordVisibility();
            _rightImagePassword.Margin = new Thickness(0, 0, 10, 0);
            _rightImagePassword.HorizontalOptions = LayoutOptions.End;
            _rightImagePassword.VerticalOptions = LayoutOptions.CenterAndExpand;
            _rightImagePassword.IsVisible = false;
            _rightImagePassword.GestureRecognizers.Add(onImageTapped);

            _containerStack.Children.Add(CustomEntryBase);
            _containerStack.Children.Add(_rightTextLbl);
            _containerStack.Children.Add(_rightImagePassword);

            Content = _containerStack;
        }
        #endregion

        #region Protected Methods
        /// <summary>
        /// On Property changed handled.
        /// </summary>
        protected override void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            base.OnPropertyChanged(propertyName);

            if (propertyName == "BorderColor")
            {
                BorderColor = BorderColor;
            }

            if (propertyName == nameof(IsCurvedCornersEnabled))
            {
                CustomEntryBase.IsCurvedCornersEnabled = IsCurvedCornersEnabled;
            }

            if (propertyName == nameof(Placeholder))
            {
                CustomEntryBase.Placeholder = Placeholder;
            }

            if (propertyName == nameof(KeyboardType))
            {
                CustomEntryBase.Keyboard = KeyboardType;
            }

            if (propertyName == nameof(ShowRightText))
            {
                _rightTextLbl.IsVisible = ShowRightText;
            }

            if (propertyName == nameof(RightText))
            {
                _rightTextLbl.Text = RightText;
            }

            if (propertyName == nameof(EnableShowPassword))
            {
                _rightImagePassword.IsVisible = EnableShowPassword;
            }

            if (propertyName == nameof(Text))
            {
                CustomEntryBase.Text = Text;
                ValueToSend = CustomEntryBase.ValueToSend;
            }

            if (propertyName == nameof(ValueToSend))
            {
                CustomEntryBase.ValueToSend = ValueToSend;
            }

            if (propertyName == nameof(FormattedValue))
            {
                CustomEntryBase.FormattedValue = FormattedValue;
            }

            if (propertyName == nameof(MaxLength))
            {
                if (MaxLength > 0 && TypeEntry == EntryType.Text)
                {
                    CustomEntryBase.MaxLength = MaxLength;
                }
            }

            if (propertyName == nameof(DecimalLength))
            {
                if (TypeEntry == EntryType.Decimal)
                {
                    var decimalBehavior = new LengthValidateBehavior
                    {
                        BindingContext = this
                    };

                    decimalBehavior.SetBinding(LengthValidateBehavior.MaxLengthProperty, nameof(MaxLength));
                    decimalBehavior.SetBinding(LengthValidateBehavior.MaxDecimalProperty, nameof(DecimalLength));
                    CustomEntryBase.Behaviors.Add(decimalBehavior);
                }
            }

            if (propertyName == nameof(TypeEntry))
            {
                if (TypeEntry == EntryType.Phone)
                {
                    SetKeyboardType();

                    var customPhoneBehavior = new EntryCustomFormatBehavior
                    {
                        BindingContext = this
                    };

                    customPhoneBehavior.SetBinding(EntryCustomFormatBehavior.TextProperty, nameof(Text));
                    customPhoneBehavior.SetBinding(EntryCustomFormatBehavior.ValueToSendProperty, nameof(ValueToSend));
                    CustomEntryBase.Behaviors.Add(customPhoneBehavior);
                    return;
                }
            }

            if (propertyName == nameof(NextView))
            {
                CustomEntryBase.NextView = NextView;
            }

            if (propertyName == nameof(PrevView))
            {
                CustomEntryBase.PrevView = PrevView;
            }

            if (propertyName == nameof(ReturnType))
            {
                CustomEntryBase.ReturnType = ReturnType;
            }

            if (propertyName == nameof(ShouldInvokeComplete))
            {
                if (ShouldInvokeComplete)
                {
                    CustomEntryBase.ShouldInvokeComplete = ShouldInvokeComplete;
                }
            }

            if (propertyName == nameof(OnCompleteCommand))
            {
                CustomEntryBase.OnCompleteCommand = OnCompleteCommand;
            }

            if (propertyName == nameof(IsPassword))
            {
                CustomEntryBase.IsPassword = IsPassword;
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Text Changed Handler.
        /// </summary>
        private void CustomEntryBase_TextChanged(object? sender, TextChangedEventArgs e)
        {
            TextChangedCommand?.Execute(e.NewTextValue);
        }

        /// <summary>
        /// Move cursor to the end when it gets focused.
        /// </summary>
        private void CustomEditor_Focused(object? sender, FocusEventArgs e)
        {
            if (CustomEntryBase.Text != null)
            {
                CustomEntryBase.CursorPosition = CustomEntryBase.Text.Length;
            }
        }

        /// <summary>
        /// Sets the type of the keyboard.
        /// </summary>
        private void SetKeyboardType()
        {
            CustomEntryBase.KeyboardType = EntryKeyboardType.Telephone;
            CustomEntryBase.Keyboard = Keyboard.Telephone;
        }

        /// <summary>
        /// Change password icon.
        /// </summary>
        /// <param name="showPassword">Show/Hide password.</param>
        private void HandlePasswordVisibility()
        {
            _rightImagePassword.Source = new FontImageSource
            {
                FontFamily = "FAIcons",
                Glyph = _showedPassword ? FAIcons.EyeSlash : FAIcons.Eye,
                Size = 17,
                Color = (Color)App.ResourceDictionary["Colors"]["Primary"]
            };
        }
        #endregion
    }
}