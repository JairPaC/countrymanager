﻿using Android.Content;
using Android.Graphics.Drawables;
using Android.Text;
using Android.Util;
using Android.Views.InputMethods;
using Android.Widget;
using CountryManager.Controls.Base;
using CountryManager.Controls.Enums;
using CountryManager.Resx;
using Microsoft.Maui.Controls.Compatibility.Platform.Android;
using Microsoft.Maui.Controls.Platform;

namespace CountryManager.Platforms.Android.Renderers
{
    public class CustomEntryRenderer : EntryRenderer
    {
        #region Constructor
        /// <summary>
        /// Constructor of <see cref="CustomEntryRenderer"/> class.
        /// </summary>
        public CustomEntryRenderer(Context context) : base(context)
        {
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// DP to Pixel converter.
        /// </summary>
        public static float DpToPixels(Context context, float valueInDp)
        {
            DisplayMetrics metrics = context.Resources.DisplayMetrics;
            return TypedValue.ApplyDimension(ComplexUnitType.Dip, valueInDp, metrics);
        }
        #endregion

        #region Protected Methods
        /// <summary>
        /// On element changed method.
        /// </summary>
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            if (e.NewElement != null)
            {
                var view = (CustomEntryBase)Element;

                Control.EditorAction += Control_EditorAction;
                FixKeyboard(view);
                SetReturnType(view);

                // creating gradient drawable for the curved background
                var _gradientBackground = new GradientDrawable();
                _gradientBackground.SetShape(ShapeType.Rectangle);
                //_gradientBackground.SetColor(view.BackgroundColor.ToAndroid());

                // Thickness of the stroke line
                _gradientBackground.SetStroke(view.IsCurvedCornersEnabled ? view.BorderWidth : 0, view.BorderColor.ToAndroid());

                // Radius for the curves
                _gradientBackground.SetCornerRadius(
                    DpToPixels(Context,
                        Convert.ToSingle(view.CornerRadius)));

                // set the background of the label
                Control.SetBackground(_gradientBackground);

                // Set padding for the internal text from border
                Control.SetPadding(
                    (int)DpToPixels(Context, Convert.ToSingle(12)),
                    Control.PaddingTop,
                    (int)DpToPixels(Context, Convert.ToSingle(12)),
                    Control.PaddingBottom);
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Gets the element.
        /// </summary>
        /// <value>The element.</value>
        private new CustomEntryBase Element
        {
            get
            {
                return base.Element as CustomEntryBase;
            }
        }

        /// <summary>
        /// Sets the type of the return.
        /// </summary>
        /// <param name="entry">Entry.</param>
        private void SetReturnType(CustomEntryBase entry)
        {
            ReturnTypeKeyboard type = entry.ReturnType;

            switch (type)
            {
                case ReturnTypeKeyboard.Go:
                    Control.ImeOptions = ImeAction.Go;
                    Control.SetImeActionLabel(AppResources.GoKeyboard, ImeAction.Go);
                    break;
                case ReturnTypeKeyboard.Next:
                    Control.ImeOptions = ImeAction.Next;
                    Control.SetImeActionLabel(AppResources.NextKeyboard, ImeAction.Next);
                    break;
                case ReturnTypeKeyboard.Send:
                    Control.ImeOptions = ImeAction.Send;
                    Control.SetImeActionLabel(AppResources.SendKeyboard, ImeAction.Send);
                    break;
                case ReturnTypeKeyboard.Search:
                    Control.ImeOptions = ImeAction.Search;
                    Control.SetImeActionLabel(AppResources.SearchText, ImeAction.Search);
                    break;
                case ReturnTypeKeyboard.Done:
                    Control.ImeOptions = ImeAction.Done;
                    Control.SetImeActionLabel(AppResources.Done, ImeAction.Done);
                    break;
                case ReturnTypeKeyboard.SignIn:
                    Control.ImeOptions = ImeAction.Go;
                    Control.SetImeActionLabel(AppResources.Login, ImeAction.Go);
                    break;
                default:
                    Control.ImeOptions = ImeAction.Done;
                    Control.SetImeActionLabel(AppResources.Done, ImeAction.Done);
                    break;
            }
        }

        /// <summary>
        /// Controls the editor action.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">E.</param>
        private void Control_EditorAction(object? sender, TextView.EditorActionEventArgs e)
        {
            Element?.SendComplete();
        }

        /// <summary>
        /// Fixs the keyboard.
        /// </summary>
        /// <param name="entry">Entry.</param>
        private void FixKeyboard(CustomEntryBase entry)
        {
            if (entry.Keyboard != Keyboard.Text || entry.IsPassword)
            {
                return;
            }

            Control.InputType = InputTypes.ClassText | InputTypes.TextFlagNoSuggestions;
        }
        #endregion
    }
}