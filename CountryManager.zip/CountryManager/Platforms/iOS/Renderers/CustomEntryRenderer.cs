﻿using CoreGraphics;
using CountryManager.Controls.Base;
using CountryManager.Controls.Enums;
using CountryManager.Resx;
using Microsoft.Maui.Controls.Compatibility.Platform.iOS;
using Microsoft.Maui.Controls.Platform;
using Microsoft.Maui.Platform;
using UIKit;

namespace CountryManager.Platforms.iOS.Renderers
{
    public class CustomEntryRenderer : EntryRenderer
    {
        #region Private Properties
        private CustomEntryBase _entryBase;
        #endregion

        #region Protected Methods
        /// <summary>
        /// On element changed method.
        /// </summary>
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            if (e.NewElement != null)
            {
                _entryBase = (CustomEntryBase)Element;

                AddReturnKeyButton(_entryBase);
                Control.LeftView = new UIView(new CGRect(0f, 0f, 9f, 20f));
                Control.AutocapitalizationType = UITextAutocapitalizationType.None;
                Control.LeftViewMode = UITextFieldViewMode.Always;
                Control.KeyboardAppearance = UIKeyboardAppearance.Default;
                Control.ReturnKeyType = UIReturnKeyType.Done;
                Control.Layer.CornerRadius = Convert.ToSingle(_entryBase.CornerRadius);
                Control.Layer.BorderColor = _entryBase.BorderColor.ToCGColor();
                Control.Layer.BorderWidth = _entryBase.BorderWidth;

                if (!_entryBase.IsCurvedCornersEnabled)
                {
                    Control.BorderStyle = UITextBorderStyle.None;
                }

                Control.ClipsToBounds = true;
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Adds the return key button.
        /// </summary>
        /// <param name="entry">Entry.</param>
        private void AddReturnKeyButton(CustomEntryBase entry)
        {
            var toolbar = new UIToolbar(new CGRect(0.0f, 0.0f, Control.Frame.Size.Width, 44.0f));
            string titleButton = String.Empty;

            if (entry.KeyboardType == EntryKeyboardType.Numeric)
            {
                Control.KeyboardType = UIKeyboardType.NumberPad;
            }
            else if (entry.KeyboardType == EntryKeyboardType.Decimal)
            {
                Control.KeyboardType = UIKeyboardType.DecimalPad;
            }
            else if (entry.KeyboardType == EntryKeyboardType.Telephone)
            {
                Control.KeyboardType = UIKeyboardType.PhonePad;
            }

            switch (entry.ReturnType)
            {
                case ReturnTypeKeyboard.Done:
                    titleButton = AppResources.Done;
                    break;
                case ReturnTypeKeyboard.Next:
                    titleButton = AppResources.NextKeyboard;
                    break;
                case ReturnTypeKeyboard.Go:
                    titleButton = AppResources.GoKeyboard;
                    break;
                case ReturnTypeKeyboard.Search:
                    titleButton = AppResources.SearchText;
                    break;
                case ReturnTypeKeyboard.SignIn:
                    titleButton = AppResources.Login;
                    break;
                default:
                    titleButton = AppResources.Done;
                    break;
            }

            if (titleButton == AppResources.Done)
            {
                var prev = new UIBarButtonItem(" ▲ ", UIBarButtonItemStyle.Bordered, HandlerEvent_Prev);
                var next = new UIBarButtonItem(" ▼ ", UIBarButtonItemStyle.Bordered, HandlerEvent_Next);
                var space = new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace);
                var done = new UIBarButtonItem(titleButton, UIBarButtonItemStyle.Bordered, HandlerEvent_Done);
                prev.Enabled = _entryBase.PrevView != null;
                next.Enabled = _entryBase.NextView != null;
                toolbar.Items = new UIBarButtonItem[]
                {
                    prev, next, space, done
                };
            }
            else
            {
                toolbar.Items = new UIBarButtonItem[]
                {
                    new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace),
                    new UIBarButtonItem(titleButton, UIBarButtonItemStyle.Bordered,HandlerEvent_Done)
                };
            }

            Control.InputAccessoryView = toolbar;
        }

        /// <summary>
        /// Handlers the event previous.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">E.</param>
        private void HandlerEvent_Prev(object sender, EventArgs e)
        {
            _entryBase.OnPrev();
        }

        /// <summary>
        /// Handlers the event next.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">E.</param>
        private void HandlerEvent_Next(object sender, EventArgs e)
        {
            _entryBase.OnNext();
        }

        /// <summary>
        /// Handlers the event done.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">E.</param>
        private void HandlerEvent_Done(object sender, EventArgs e)
        {
            _entryBase.SendComplete();
        }
        #endregion
    }
}