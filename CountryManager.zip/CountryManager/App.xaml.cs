﻿using System.Diagnostics;
using CountryManager.Services;
using CountryManager.Services.Implementation;
using CountryManager.Views;

namespace CountryManager;

public partial class App : Application
{
    #region Private Properties
    private IAppContainer _appContainer;
    #endregion

    #region Public Properties
    public static Dictionary<string, ResourceDictionary>? ResourceDictionary;
    #endregion

    #region Constructor
    /// <summary>
    /// Constructor of <see cref="App"/> class.
    /// </summary>
    public App()
    {
        RegisterTypes();
        OnInitialized();
    }
    #endregion

    #region Private Methods
    /// <summary>
    /// On init.
    /// </summary>
    protected void OnInitialized()
    {
        InitializeComponent();
        LoadAppResources();

        try
        {
            MainPage = new LoginPage();
        }
        catch (Exception ex)
        {
#if DEBUG
            Debug.WriteLine(ex.Message);
#endif
        }
    }

    /// <summary>
    /// Register Dependencies.
    /// </summary>
    protected void RegisterTypes()
    {
        _appContainer = AppContainer.Instance;
        _appContainer.RegisterDependencies();
    }

    /// <summary>
    /// Load App Resources.
    /// </summary>
    private void LoadAppResources()
    {
        ResourceDictionary = new Dictionary<string, ResourceDictionary>();

        foreach (var dictionary in Current.Resources.MergedDictionaries)
        {
            string key = dictionary.Source.OriginalString.Split(';').First().Split('/').Last().Split('.').First();
            ResourceDictionary.Add(key, dictionary);
        }
    }
    #endregion
}