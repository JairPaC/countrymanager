﻿using CommunityToolkit.Mvvm.ComponentModel;
using System.Collections.ObjectModel;
using CountryManager.Services;
using CountryManager.ViewModels.Base;
using CountryManager.Models;
using CommunityToolkit.Mvvm.Input;
using CountryManager.Helper;
using CountryManager.Resx;
using System.Diagnostics.Metrics;
using CountryManager.Controls.Enums;
using CountryManager.Views.Modals;
using CountryManager.Helper.Enums;

namespace CountryManager.ViewModels
{
    public partial class DashboardViewModal : BaseViewModel
    {
        #region Readonly Properties
        private readonly ICloudRestService _cloudRestService;
        private readonly IDialogService _dialogService;
        private readonly INavigationService _navigationService;
        #endregion

        #region Private Properties
        private bool _isFetching;
        private bool _moreItemsToLoad = true;
        private int _page = 1;
        private int _limitPerPage = 100;
        private bool _initLoading;
        #endregion

        #region Bindable Properties
        [ObservableProperty]
        private ObservableCollection<CountryDto> _countries;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor of <see cref="DashboardViewModal"/> class.
        /// </summary>
        /// <param name="cloudRestService">Cloud REST Service.</param>
        /// <param name="dialogService">Dialogs Service.</param>
        /// <param name="navigationService">Navigation Service.</param>
        public DashboardViewModal(ICloudRestService cloudRestService, IDialogService dialogService, INavigationService navigationService)
        {
            _cloudRestService = cloudRestService;
            _dialogService = dialogService;
            _navigationService = navigationService;

            Countries = new ObservableCollection<CountryDto>();
            FetchAllContries();
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Navigation back handler.
        /// </summary>
        /// <param name="param"></param>
        public override void OnGoingBack(NavigationParameters param)
        {
            base.OnGoingBack(param);

            if (param.ContainsKey(Constants.IsSuccessKey))
            {
                var response = (int)param[Constants.IsSuccessKey];

                if (response == 0)
                {
                    _page = 1;
                    FetchAllContries();
                }
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Fetch all countries.
        /// </summary>
        /// <param name="page">Page number.</param>
        /// <param name="limit">Limit per page.</param>
        private async void FetchAllContries(bool fromScroll = false)
        {
            if (_initLoading)
            {
                return;
            }

            _initLoading = true;

            if (!fromScroll)
            {
                // Show loading in the first fetch. to make the scroll smoothly
                await _dialogService.ShowLoading();
            }
            
            var countries = await _cloudRestService.GetAllCountries(_page, _limitPerPage);

            if (countries != null && countries.Countries != null)
            {
                if (countries.Countries.Count == 0)
                {
                    _moreItemsToLoad = false;
                    return;
                }

                foreach (var item in countries.Countries)
                {
                    Countries.Add(item);
                }
            }

            _initLoading = false;
            await _dialogService.HideLoading();
        }

        /// <summary>
        /// On scrolled down.
        /// </summary>
        [RelayCommand]
        private void ScrollDown()
        {
            if (_isFetching)
            {
                return;
            }

            if (!_moreItemsToLoad)
            {
                return;
            }

            _isFetching = true;
            _page++;

            if (!_initLoading)
            {
                FetchAllContries(true);
            }
        }

        /// <summary>
        /// Item selected.
        /// </summary>
        /// <param name="item">Selected item.</param>
        [RelayCommand]
        private async void ItemSelected(CountryDto item)
        {
            var param = new NavigationParameters();
            param.Add(Constants.CountryIdKey, item.Id);
            await _navigationService.PushAsync(typeof(DetailsViewModel), parameter: param);
        }

        /// <summary>
        /// Delete item selected.
        /// </summary>
        /// <param name="item">Selected item.</param>
        [RelayCommand]
        private async void DeleteItemSelected(CountryDto item)
        {
            await _dialogService.DisplayYesNoAlert(AppResources.DeleteTitle,
                AppResources.DeleteMessage, AppResources.Cancel, AppResources.OK, secondButtonType: ModalButtonType.Primary,
                task: async () => {
                    await _dialogService.ShowLoading();
                    var response = await _cloudRestService.DeleteCountry(item.Id);
                    await _dialogService.HideLoading();

                    if (response == "success")
                    {
                        // Loading more efficiently
                        Countries.Remove(item);
                        await ToastMessageModal.Show(AppResources.SuccessMessage, ToastType.Success);
                    }
                    else if (response == "Not Found")
                    {
                        await ToastMessageModal.Show(response, ToastType.Success);
                    }
                    else
                    {
                        await ToastMessageModal.Show(AppResources.ErrorMessage, ToastType.Success);
                    }
                });
        }

        /// <summary>
        /// Add a new country.
        /// </summary>
        [RelayCommand]
        private async void AddItem()
        {
            var param = new NavigationParameters();
            param.Add(Constants.CountryIdKey, 0);
            await _navigationService.PushAsync(typeof(DetailsViewModel), parameter: param);
        }
        #endregion
    }
}

