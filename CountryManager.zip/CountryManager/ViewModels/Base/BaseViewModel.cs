﻿using CommunityToolkit.Mvvm.ComponentModel;
using CountryManager.Models;

namespace CountryManager.ViewModels.Base
{
    public partial class BaseViewModel : ObservableRecipient
    {
        #region Private Properties
        #endregion

        #region Bindable Properties
        [ObservableProperty]
        private string? _title;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor of <see cref="BaseViewModel"/> class.
        /// </summary>
        public BaseViewModel() { }
        #endregion

        #region Virtual Methods
        public virtual void Init() { }
        public virtual void OnInit(NavigationParameters param) { }
        public virtual void OnDisappearing() { }
        public virtual void OnAppearing() { }
        public virtual void OnGoingBack(NavigationParameters param) { }
        #endregion
    }
}

