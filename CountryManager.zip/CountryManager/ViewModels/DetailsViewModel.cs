﻿using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CountryManager.Controls.Enums;
using CountryManager.Helper;
using CountryManager.Helper.Enums;
using CountryManager.Models;
using CountryManager.Resx;
using CountryManager.Services;
using CountryManager.ViewModels.Base;
using CountryManager.Views.Modals;

namespace CountryManager.ViewModels
{
    public partial class DetailsViewModel : BaseViewModel
	{
        #region MyRegion
        private readonly ICloudRestService _cloudRestService;
        private readonly IDialogService _dialogService;
        private readonly INavigationService _navigationService;
        #endregion

        #region Private Methods
        private bool _isEditing;
        private int _countryId;
        #endregion

        #region Bindable Properties
        [ObservableProperty]
        private CountryDto _country;

        [ObservableProperty]
        private bool _showStateList;

        [ObservableProperty]
        private ObservableCollection<StateDto> _states;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor of <see cref="DetailsViewModel"/> class.
        /// </summary>
        /// <param name="cloudRestService">Cloud REST Service.</param>
        /// <param name="dialogService">Dialogs Service.</param>
        /// <param name="navigationService">Navigation Service.</param>
        public DetailsViewModel(ICloudRestService cloudRestService, IDialogService dialogService, INavigationService navigationService)
        {
            _cloudRestService = cloudRestService;
            _dialogService = dialogService;
            _navigationService = navigationService;
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Navigated handler.
        /// </summary>
        public override async void OnInit(NavigationParameters param)
        {
            base.OnInit(param);

            if (param.ContainsKey(Constants.CountryIdKey))
            {
                _countryId = (int)param[Constants.CountryIdKey];

                if (_countryId == 0)
                {
                    _isEditing = false;
                    ShowStateList = false;
                    Title = AppResources.NewCountry;
                    Country = new CountryDto();
                }
                else
                {
                    _isEditing = true;
                    ShowStateList = true;
                    States = new ObservableCollection<StateDto>();
                    Title = AppResources.Details;
                    await _dialogService.ShowLoading();
                    var countryResponse = await _cloudRestService.GetCountry(_countryId);
                    var statesResponse = await _cloudRestService.GetStates(_countryId);

                    if (countryResponse != null && statesResponse != null)
                    {
                        Country = countryResponse;

                        foreach (var item in statesResponse)
                        {
                            States.Add(item);
                        }
                    }

                    await _dialogService.HideLoading();
                }
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Save country.
        /// </summary>
        [RelayCommand]
        private async void SaveCountry()
        {
            if (string.IsNullOrEmpty(Country.Name)
                || string.IsNullOrEmpty(Country.Alpha2)
                || string.IsNullOrEmpty(Country.Alpha3)
                || string.IsNullOrEmpty(Country.Code)
                || string.IsNullOrEmpty(Country.ISO))
            {
                await _dialogService.DisplayOkAlert(AppResources.EmptyCountryErrorTitle, AppResources.EmptyCountryErrorMessage, AppResources.OK);
                return;
            }

            await _dialogService.ShowLoading();
            int? response = null;

            if (_isEditing)
            {
                var result = await _cloudRestService.UpdateCountry(Country);
                response = result ? 1 : null;
            }
            else
            {
                response = await _cloudRestService.CreateCountry(Country);
            }

            await _dialogService.HideLoading();

            if (response != null)
            {
                var param = new NavigationParameters();
                param.Add(Constants.IsSuccessKey, 1);
                await ToastMessageModal.Show(AppResources.SuccessMessage, ToastType.Success);
                await _navigationService.GoBack(param);
            }
            else
            {
                await ToastMessageModal.Show(AppResources.ErrorMessage, ToastType.Error);
            }
        }

        /// <summary>
        /// Item selected.
        /// </summary>
        /// <param name="item">Selected item.</param>
        [RelayCommand]
        private async void ItemSelected(StateDto item)
        {
            // TODO Show modal to edit only the Name. OperationModal.xaml
        }

        /// <summary>
        /// Delete item selected.
        /// </summary>
        /// <param name="item">Selected item.</param>
        [RelayCommand]
        private async void DeleteItemSelected(StateDto item)
        {
            await _dialogService.DisplayYesNoAlert(AppResources.DeleteTitle,
                AppResources.DeleteMessage, AppResources.Cancel, AppResources.OK, secondButtonType: ModalButtonType.Primary,
                task: async () => {
                    await _dialogService.ShowLoading();
                    var response = await _cloudRestService.DeleteState(_countryId, item.Id);
                    await _dialogService.HideLoading();

                    if (response == "success")
                    {
                        // Loading more efficiently
                        States.Remove(item);
                        await ToastMessageModal.Show(AppResources.SuccessMessage, ToastType.Success);
                    }
                    else if (response == "Not Found")
                    {
                        await ToastMessageModal.Show(response, ToastType.Success);
                    }
                    else
                    {
                        await ToastMessageModal.Show(AppResources.ErrorMessage, ToastType.Success);
                    }
                });
        }
        #endregion
    }
}

