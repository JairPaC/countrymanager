﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CountryManager.Helper;
using CountryManager.Resx;
using CountryManager.Services;
using CountryManager.ViewModels.Base;
using CountryManager.Views;

namespace CountryManager.ViewModels
{
    public partial class LoginViewModel : BaseViewModel
	{
        #region Readonly Services
        private readonly IDialogService _dialogService;
        #endregion

        #region Bindable Properties
        [ObservableProperty]
        private string _username;

        [ObservableProperty]
        private string _password;

        [ObservableProperty]
        private bool _showErrorMessage;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor of <see cref="LoginViewModel"/> class.
        /// </summary>
        /// <param name="dialogService">Dialog Service.</param>
        public LoginViewModel(IDialogService dialogService)
        {
            _dialogService = dialogService;
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Login process.
        /// </summary>
        [RelayCommand]
        private async Task LoginRequest()
        {
            try
            {
                ShowErrorMessage = false;

                if (string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(Password))
                {
                    ShowErrorMessage = true;
                    return;
                }

                if (!Utils.IsEmailValid(Username))
                {
                    ShowErrorMessage = true;
                    return;
                }

                await _dialogService.ShowLoading(AppResources.LoggingIn);
                await Task.Delay(2000); // Like the App calls the api.

                // Validating username and password
                if (Username == Constants.Username && Password == Constants.Password)
                {
                    // If we get a 200, we can store the username on the preferences to avoid typing again.
                    await _dialogService.HideLoading();
                    Application.Current.MainPage = new NavigationPage(new DashboardPage());
                }
                else
                {
                    await _dialogService.DisplayOkAlert(AppResources.Login, AppResources.InvalidLoginMessage);
                }
            }
            catch (Exception ex)
            {
            }
        }
        #endregion
    }
}

